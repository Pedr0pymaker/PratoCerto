<?php
declare(strict_types=1);
require_once __DIR__.'/server/bootstrap.php';
$slug=trim(parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH),'/');
if($slug==='index.php')$slug='';
$pages=['','login','dashboard','estoque','perdas','compras','alertas','usuarios','receitas','relatorios','ia','configuracoes'];
if(!in_array($slug,$pages,true)){http_response_code(404);exit('Página não encontrada.');}
if($slug!==''&&$slug!=='login'){
    try{if(!user()){header('Location: /login?from='.rawurlencode('/'.$slug));exit;}}
    catch(Throwable $e){error_log('[PratoCerto/front] '.$e->getMessage());}
}
header('Cache-Control: no-cache, no-store, must-revalidate');
?><!DOCTYPE html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#16a34a"><title>PratoCerto — Gestão de Estoque</title><link rel="icon" href="/assets/favicon.ico"><link rel="stylesheet" href="/assets/css/pratocerto.css">
<script type="importmap">{
  "imports": {
    "react": "https://esm.sh/react@19.2.0",
    "react/jsx-runtime": "https://esm.sh/react@19.2.0/jsx-runtime?external=react",
    "react-dom/client": "https://esm.sh/react-dom@19.2.0/client?external=react"
  }
}</script></head><body><div id="root"><div style="min-height:90vh;display:grid;place-items:center;font:16px system-ui;color:#15803d">🍽️ Carregando PratoCerto…</div></div>
<script type="module">
import React from 'react';
import {createRoot} from 'react-dom/client';
const pages = {
  "": () => import('/assets/js/pages/home.js'),
  "login": () => import('/assets/js/pages/login.js'),
  "dashboard": () => import('/assets/js/pages/dashboard.js'),
  "estoque": () => import('/assets/js/pages/estoque.js'),
  "perdas": () => import('/assets/js/pages/perdas.js'),
  "compras": () => import('/assets/js/pages/compras.js'),
  "alertas": () => import('/assets/js/pages/alertas.js'),
  "usuarios": () => import('/assets/js/pages/usuarios.js'),
  "receitas": () => import('/assets/js/pages/receitas.js'),
  "relatorios": () => import('/assets/js/pages/relatorios.js'),
  "ia": () => import('/assets/js/pages/ia.js'),
  "configuracoes": () => import('/assets/js/pages/configuracoes.js')
};
const key=decodeURIComponent(window.location.pathname.replace(/^\/+|\/+$/g,''));
const root=createRoot(document.getElementById('root'));
try {
 const page=(await (pages[key]??pages[''])()).default;
 if(!page)throw new Error('Página não disponível');
 if(key&&key!=='login'){
   const Shell=(await import('/assets/js/components/AppShell.js')).default;
   root.render(React.createElement(Shell,null,React.createElement(page)));
 }else root.render(React.createElement(page));
}catch(error){console.error(error);document.getElementById('root').innerHTML='<div style="font:16px system-ui;padding:35px;max-width:650px;margin:40px auto;color:#991b1b;background:#fff1f2;border-radius:14px"><h1>Não foi possível carregar a interface</h1><p>Confira sua conexão com a internet e permita carregar os módulos React do servidor de arquivos CDN. Atualize a página para tentar novamente.</p><a href="/login">Abrir login</a></div>'}
</script></body></html>
