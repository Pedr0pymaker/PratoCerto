<?php
declare(strict_types=1);
require_once __DIR__.'/server/bootstrap.php';
header('Cache-Control: no-store');
$erro='';$pronto=false;
try {
    $temGerente=(int)(one('SELECT COUNT(*) total FROM usuarios')['total']??0)>0;
    $configured=(bool)preg_match('/^[a-f0-9]{64}$/D', cfg('SETUP_TOKEN'));
    if(!$temGerente&&$configured&&$_SERVER['REQUEST_METHOD']==='POST'){
        sameOrigin();
        $token=(string)($_POST['setup_token']??'');$csrf=(string)($_POST['csrf']??'');
        $nome=trim((string)($_POST['nome']??''));$email=strtolower(trim((string)($_POST['email']??'')));$pass=(string)($_POST['senha']??'');
        if(!hash_equals($_SESSION['setup_csrf']??'',$csrf))$erro='Formulário expirado. Recarregue a página.';
        elseif(!hash_equals(cfg('SETUP_TOKEN'),$token)){$erro='Token de instalação incorreto.';sleep(1);}
        elseif(charLen($nome)<3||charLen($nome)>150||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>150||strlen($pass)<10)$erro='Informe nome, e-mail válido e senha com pelo menos 10 caracteres.';
        else {
            $pdo=db();$pdo->beginTransaction();
            try{
                if(one('SELECT id FROM usuarios LIMIT 1 FOR UPDATE')){$pdo->rollBack();$erro='A primeira conta já foi criada.';}
                else {execute('INSERT INTO usuarios (id,nome,email,senhaHash,perfil,ativo,atualizadoEm) VALUES (?,?,?,?,"GERENTE",1,NOW(3))',[uid(),$nome,$email,password_hash($pass,PASSWORD_BCRYPT)]);$pdo->commit();$pronto=true;}
            }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
        }
    }
} catch(Throwable $e) {error_log('[PratoCerto/setup] '.$e->getMessage());$erro='Verifique o MySQL e o arquivo .env antes de criar o gerente.';$temGerente=false;$configured=false;}
if(empty($_SESSION['setup_csrf']))$_SESSION['setup_csrf']=bin2hex(random_bytes(32));
function h($s):string{return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Instalar gerente — PratoCerto</title><style>body{margin:0;background:#f0fdf4;font:16px system-ui;color:#1f2937}main{max-width:470px;margin:8vh auto;padding:30px;background:white;border:1px solid #dcfce7;border-radius:18px;box-shadow:0 8px 28px #164e6312}h1{color:#166534}label{display:block;margin-top:14px;font-size:14px;font-weight:bold}input{width:100%;box-sizing:border-box;padding:12px;margin-top:5px;border:1px solid #ccc;border-radius:8px}button{width:100%;background:#15803d;color:#fff;border:0;padding:14px;border-radius:9px;font-weight:700;margin-top:22px;cursor:pointer}p{line-height:1.6}.error{padding:10px;color:#b91c1c;background:#fef2f2;border-radius:8px}</style></head><body><main><h1>🍽️ Primeiro gerente</h1>
<?php if($erro):?><p class="error"><?=h($erro)?></p><?php endif;?>
<?php if(!empty($temGerente)||$pronto):?><p>✅ A conta inicial já foi criada. Este instalador não permite cadastrar outro gerente.</p><p><a href="/login">Acessar login</a></p>
<?php elseif(!$configured):?><p>Configure o MySQL e um <code>SETUP_TOKEN</code> aleatório, com pelo menos 32 caracteres, no arquivo privado <code>htdocs/.env</code>. Veja <b>INSTALAR_INFINITYFREE.md</b>.</p>
<?php else:?><p>Use o token secreto salvo no seu <code>.env</code>. Esta página só cria o primeiro usuário, sem senhas de demonstração.</p><form method="post" autocomplete="off"><input type="hidden" name="csrf" value="<?=h($_SESSION['setup_csrf'])?>"><label>Nome<input name="nome" minlength="3" maxlength="150" required></label><label>E-mail<input type="email" name="email" maxlength="150" required></label><label>Senha pessoal (10+ caracteres)<input type="password" name="senha" minlength="10" autocomplete="new-password" required></label><label>Token de instalação (<code>SETUP_TOKEN</code>)<input type="password" name="setup_token" autocomplete="off" required></label><button type="submit">Criar gerente</button></form><?php endif;?><p><a href="/">Voltar ao PratoCerto</a></p></main></body></html>
