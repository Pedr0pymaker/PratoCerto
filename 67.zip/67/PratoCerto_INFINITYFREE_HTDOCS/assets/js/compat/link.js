import {createElement} from 'react';
export default function Link({href='#',children,prefetch,replace,scroll,...props}) {return createElement('a',{href,...props},children);}
