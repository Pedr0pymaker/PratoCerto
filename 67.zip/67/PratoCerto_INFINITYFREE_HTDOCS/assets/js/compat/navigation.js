function safeLocal(path) {
  if (typeof path !== 'string' || !path.startsWith('/') || path.startsWith('//') || /[\x00-\x1f\x7f]/.test(path)) return '/dashboard';
  return path;
}
export function usePathname(){return window.location.pathname;}
export function useRouter(){return {
  push(path){window.location.assign(safeLocal(path));},
  replace(path){window.location.replace(safeLocal(path));},
  refresh(){},
  back(){window.history.back()}
};}
export function useSearchParams(){return new URLSearchParams(window.location.search);}
