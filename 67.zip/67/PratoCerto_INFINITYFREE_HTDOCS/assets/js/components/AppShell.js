"use client";
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from "react";
import Sidebar from "/assets/js/components/Sidebar.js";
export default function AppShell({ children, pageTitle }) {
    const [mobileOpen, setMobileOpen] = useState(false);
    return (_jsxs("div", { style: { display: "flex", minHeight: "100dvh" }, children: [_jsx(Sidebar, { isMobileOpen: mobileOpen, onMobileClose: () => setMobileOpen(false) }), _jsxs("div", { style: {
                    flex: 1,
                    display: "flex",
                    flexDirection: "column",
                    minWidth: 0,
                    // Em telas grandes, empurra o conteúdo para a direita da sidebar
                    marginLeft: "var(--sidebar-width)",
                    transition: "margin-left 0.25s ease",
                }, className: "main-content", children: [_jsxs("header", { role: "banner", style: {
                            height: "60px",
                            background: "var(--color-surface)",
                            borderBottom: "1px solid var(--color-border)",
                            display: "flex",
                            alignItems: "center",
                            padding: "0 24px",
                            gap: "16px",
                            position: "sticky",
                            top: 0,
                            zIndex: 10,
                            boxShadow: "var(--shadow-sm)",
                        }, children: [_jsx("button", { id: "btn-menu-mobile", "aria-label": "Abrir menu de navega\u00E7\u00E3o", "aria-expanded": mobileOpen, "aria-controls": "sidebar-nav", onClick: () => setMobileOpen(true), style: {
                                    display: "none",
                                    background: "none",
                                    border: "none",
                                    cursor: "pointer",
                                    padding: "8px",
                                    borderRadius: "6px",
                                    color: "var(--color-text)",
                                    fontSize: "20px",
                                }, className: "mobile-menu-btn", children: "\u2630" }), pageTitle && (_jsx("h1", { style: {
                                    margin: 0,
                                    fontSize: "18px",
                                    fontWeight: 600,
                                    color: "var(--color-text)",
                                }, children: pageTitle })), _jsx("div", { style: { flex: 1 } }), _jsxs("span", { style: {
                                    fontSize: "12px",
                                    color: "var(--color-text-muted)",
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "6px",
                                }, children: [_jsx("span", { style: {
                                            width: "8px",
                                            height: "8px",
                                            borderRadius: "50%",
                                            background: "#22c55e",
                                            display: "inline-block",
                                        }, title: "Sistema operando normalmente" }), "Sistema ativo"] })] }), _jsx("main", { id: "main-content", role: "main", tabIndex: -1, style: {
                            flex: 1,
                            padding: "24px",
                            overflowY: "auto",
                        }, children: children })] }), _jsx("style", { children: `
        @media (max-width: 1023px) {
          .main-content {
            margin-left: 0 !important;
          }
          .mobile-menu-btn {
            display: flex !important;
          }
        }
      ` })] }));
}
