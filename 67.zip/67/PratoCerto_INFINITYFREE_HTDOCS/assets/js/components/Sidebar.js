"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import Link from "/assets/js/compat/link.js";
import { usePathname, useRouter } from "/assets/js/compat/navigation.js";
import { useEffect, useState } from "react";
const navItems = [
    {
        href: "/dashboard",
        label: "Dashboard",
        icon: "📊",
        description: "Visão geral do estabelecimento",
    },
    {
        href: "/estoque",
        label: "Estoque",
        icon: "📦",
        description: "Produtos e movimentações",
    },
    {
        href: "/alertas",
        label: "Alertas",
        icon: "🔔",
        description: "Estoque baixo e validade dos lotes",
    },
    {
        href: "/perdas",
        label: "Perdas",
        icon: "⚠️",
        description: "Registro de desperdícios",
    },
    {
        href: "/compras",
        label: "Compras",
        icon: "🛒",
        description: "Entradas e fornecedores",
    },
    {
        href: "/receitas",
        label: "Receitas",
        icon: "🍽️",
        description: "Fichas técnicas e ingredientes",
    },
    {
        href: "/relatorios",
        label: "Relatórios",
        icon: "📈",
        description: "Análises e exportações",
    },
    {
        href: "/ia",
        label: "PratoCerto IA",
        icon: "🤖",
        description: "Assistente inteligente",
    },
    {
        href: "/usuarios",
        label: "Usuários",
        icon: "👥",
        description: "Equipe e permissões",
        apenasGerente: true,
    },
    {
        href: "/configuracoes",
        label: "Configurações",
        icon: "⚙️",
        description: "Preferências do sistema",
    },
];
export default function Sidebar({ isMobileOpen, onMobileClose }) {
    const pathname = usePathname();
    const router = useRouter();
    const [usuario, setUsuario] = useState(null);
    const [saindo, setSaindo] = useState(false);
    useEffect(() => {
        fetch("/api/auth/me")
            .then((res) => (res.ok ? res.json() : null))
            .then((data) => {
            if (data?.usuario) {
                setUsuario(data.usuario);
            }
        })
            .catch(() => { });
    }, []);
    async function handleLogout() {
        setSaindo(true);
        try {
            await fetch("/api/auth/logout", { method: "POST" });
            router.push("/login");
            router.refresh();
        }
        catch {
            router.push("/login");
        }
    }
    // Se o perfil for FUNCIONARIO, oculta itens exclusivos do GERENTE
    const itensVisiveis = navItems.filter((item) => {
        if (item.apenasGerente && usuario && usuario.perfil !== "GERENTE") {
            return false;
        }
        return true;
    });
    return (_jsxs(_Fragment, { children: [isMobileOpen && (_jsx("div", { className: "fixed inset-0 z-20 bg-black/50 lg:hidden", onClick: onMobileClose, "aria-hidden": "true" })), _jsxs("aside", { role: "navigation", "aria-label": "Menu principal", style: {
                    width: "var(--sidebar-width)",
                    background: "var(--sidebar-bg)",
                    color: "var(--sidebar-text)",
                    position: "fixed",
                    top: 0,
                    left: 0,
                    height: "100dvh",
                    display: "flex",
                    flexDirection: "column",
                    zIndex: 30,
                    transition: "transform 0.25s ease",
                    transform: isMobileOpen ? "translateX(0)" : undefined,
                    overflowY: "auto",
                }, className: !isMobileOpen ? "max-lg:translate-x-[-100%]" : "", children: [_jsx("div", { style: {
                            padding: "24px 20px 20px",
                            borderBottom: "1px solid rgba(255,255,255,0.08)",
                        }, children: _jsxs(Link, { href: "/dashboard", onClick: onMobileClose, style: { textDecoration: "none", display: "flex", alignItems: "center", gap: "10px" }, children: [_jsx("span", { style: { fontSize: "28px" }, children: "\uD83C\uDF7D\uFE0F" }), _jsxs("div", { children: [_jsx("p", { style: {
                                                margin: 0,
                                                fontSize: "18px",
                                                fontWeight: 700,
                                                color: "#ffffff",
                                                letterSpacing: "-0.3px",
                                            }, children: "PratoCerto" }), _jsx("p", { style: {
                                                margin: 0,
                                                fontSize: "11px",
                                                color: "rgba(255,255,255,0.45)",
                                                letterSpacing: "0.5px",
                                                textTransform: "uppercase",
                                            }, children: "Gest\u00E3o de Estoque" })] })] }) }), _jsx("nav", { style: { flex: 1, padding: "12px 8px" }, children: _jsx("ul", { style: { listStyle: "none", margin: 0, padding: 0 }, children: itensVisiveis.map((item) => {
                                const isActive = pathname === item.href ||
                                    (pathname.startsWith(item.href + "/") && item.href !== "/dashboard");
                                return (_jsx("li", { style: { marginBottom: "2px" }, children: _jsxs(Link, { href: item.href, onClick: onMobileClose, "aria-current": isActive ? "page" : undefined, title: item.description, style: {
                                            display: "flex",
                                            alignItems: "center",
                                            gap: "12px",
                                            padding: "10px 12px",
                                            borderRadius: "8px",
                                            textDecoration: "none",
                                            color: isActive ? "#ffffff" : "rgba(226,232,240,0.75)",
                                            background: isActive
                                                ? "var(--sidebar-active)"
                                                : "transparent",
                                            transition: "all var(--transition)",
                                            fontSize: "14px",
                                            fontWeight: isActive ? 600 : 400,
                                        }, className: "sidebar-link", children: [_jsx("span", { style: { fontSize: "18px", flexShrink: 0 }, children: item.icon }), _jsx("span", { children: item.label })] }) }, item.href));
                            }) }) }), _jsxs("div", { style: {
                            padding: "16px",
                            borderTop: "1px solid rgba(255,255,255,0.08)",
                            background: "rgba(0,0,0,0.15)",
                        }, children: [usuario ? (_jsxs("div", { style: { marginBottom: "12px" }, children: [_jsxs("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "4px" }, children: [_jsx("strong", { style: { fontSize: "13px", color: "#ffffff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: usuario.nome }), _jsx("span", { style: {
                                                    background: usuario.perfil === "GERENTE" ? "rgba(79, 70, 229, 0.4)" : "rgba(255,255,255,0.12)",
                                                    color: usuario.perfil === "GERENTE" ? "#c7d2fe" : "rgba(255,255,255,0.8)",
                                                    fontSize: "10px",
                                                    fontWeight: 700,
                                                    padding: "2px 6px",
                                                    borderRadius: "4px",
                                                    letterSpacing: "0.04em",
                                                }, children: usuario.perfil })] }), _jsx("p", { style: { margin: 0, fontSize: "11px", color: "rgba(255,255,255,0.45)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: usuario.email })] })) : (_jsx("p", { style: { margin: "0 0 10px", fontSize: "12px", color: "rgba(255,255,255,0.45)" }, children: "Sess\u00E3o ativa" })), _jsxs("button", { id: "btn-logout", onClick: handleLogout, disabled: saindo, style: {
                                    width: "100%",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    gap: "8px",
                                    background: "rgba(239, 68, 68, 0.15)",
                                    color: "#fca5a5",
                                    border: "1px solid rgba(239, 68, 68, 0.3)",
                                    borderRadius: "6px",
                                    padding: "8px 12px",
                                    fontSize: "12px",
                                    fontWeight: 600,
                                    cursor: saindo ? "not-allowed" : "pointer",
                                    transition: "background var(--transition)",
                                }, onMouseEnter: (e) => (e.currentTarget.style.background = "rgba(239, 68, 68, 0.25)"), onMouseLeave: (e) => (e.currentTarget.style.background = "rgba(239, 68, 68, 0.15)"), children: [_jsx("span", { children: "\uD83D\uDEAA" }), _jsx("span", { children: saindo ? "Saindo..." : "Sair da conta" })] })] })] }), _jsx("style", { children: `
        .sidebar-link:hover:not([aria-current="page"]) {
          background: var(--sidebar-hover) !important;
          color: #ffffff !important;
        }
      ` })] }));
}
