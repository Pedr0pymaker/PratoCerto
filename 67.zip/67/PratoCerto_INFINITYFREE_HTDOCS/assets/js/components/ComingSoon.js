import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
export default function ComingSoon({ title, description, icon, plannedFeatures = [], }) {
    return (_jsxs("div", { style: {
            maxWidth: "600px",
            margin: "40px auto",
            textAlign: "center",
            padding: "0 16px",
        }, children: [_jsx("div", { style: {
                    fontSize: "64px",
                    marginBottom: "24px",
                    lineHeight: 1,
                }, "aria-hidden": "true", children: icon }), _jsx("h2", { style: {
                    fontSize: "24px",
                    fontWeight: 700,
                    color: "var(--color-text)",
                    margin: "0 0 12px",
                }, children: title }), _jsx("p", { style: {
                    fontSize: "15px",
                    color: "var(--color-text-muted)",
                    margin: "0 0 32px",
                    lineHeight: 1.6,
                }, children: description }), _jsx("span", { style: {
                    display: "inline-block",
                    background: "#fef3c7",
                    color: "#92400e",
                    border: "1px solid #fcd34d",
                    borderRadius: "20px",
                    padding: "6px 16px",
                    fontSize: "13px",
                    fontWeight: 600,
                    marginBottom: "32px",
                }, children: "\uD83D\uDD27 Em desenvolvimento" }), plannedFeatures.length > 0 && (_jsxs("div", { style: {
                    background: "var(--color-surface)",
                    border: "1px solid var(--color-border)",
                    borderRadius: "12px",
                    padding: "20px 24px",
                    textAlign: "left",
                }, children: [_jsx("p", { style: {
                            margin: "0 0 12px",
                            fontSize: "13px",
                            fontWeight: 600,
                            color: "var(--color-text-muted)",
                            textTransform: "uppercase",
                            letterSpacing: "0.5px",
                        }, children: "Funcionalidades previstas" }), _jsx("ul", { style: {
                            margin: 0,
                            padding: 0,
                            listStyle: "none",
                        }, children: plannedFeatures.map((feature, index) => (_jsxs("li", { style: {
                                display: "flex",
                                alignItems: "flex-start",
                                gap: "8px",
                                padding: "6px 0",
                                fontSize: "14px",
                                color: "var(--color-text)",
                                borderTop: index > 0 ? "1px solid var(--color-border)" : "none",
                            }, children: [_jsx("span", { style: { color: "var(--color-primary)", flexShrink: 0, marginTop: "1px" }, "aria-hidden": "true", children: "\u2713" }), feature] }, index))) })] }))] }));
}
