import { jsx as _jsx } from "react/jsx-runtime";
import UsuariosClient from "/assets/js/pages/usuariosClient.js";
export const metadata = {
    title: "Usuários — PratoCerto",
    description: "Gerenciamento de usuários e permissões.",
};
export default function UsuariosPage() {
    return _jsx(UsuariosClient, {});
}
