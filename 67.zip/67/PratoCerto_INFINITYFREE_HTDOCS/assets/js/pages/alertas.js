import { jsx as _jsx } from "react/jsx-runtime";
import AlertasClient from "/assets/js/pages/alertasClient.js";
export const metadata = {
    title: "Alertas — PratoCerto",
    description: "Acompanhe estoque mínimo e validade dos lotes.",
};
export default function AlertasPage() {
    return _jsx(AlertasClient, {});
}
