"use client";
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState, useEffect, useCallback } from "react";
export default function UsuariosClient() {
    const [usuarios, setUsuarios] = useState([]);
    const [carregando, setCarregando] = useState(true);
    const [erroCarregamento, setErroCarregamento] = useState(null);
    const [modalAberto, setModalAberto] = useState(false);
    const [nome, setNome] = useState("");
    const [email, setEmail] = useState("");
    const [senha, setSenha] = useState("");
    const [perfil, setPerfil] = useState("FUNCIONARIO");
    const [salvando, setSalvando] = useState(false);
    const [errosForm, setErrosForm] = useState({});
    const [mensagemSucesso, setMensagemSucesso] = useState(null);
    const [erroEnvio, setErroEnvio] = useState(null);
    const carregarUsuarios = useCallback(async () => {
        try {
            const res = await fetch("/api/usuarios");
            if (!res.ok) {
                if (res.status === 403) {
                    throw new Error("Acesso restrito ao perfil GERENTE.");
                }
                throw new Error("Não foi possível carregar os usuários.");
            }
            const data = await res.json();
            setUsuarios(data.usuarios || []);
            setErroCarregamento(null);
        }
        catch (err) {
            setErroCarregamento(err instanceof Error ? err.message : "Erro desconhecido.");
        }
        finally {
            setCarregando(false);
        }
    }, []);
    useEffect(() => {
        let ignore = false;
        async function init() {
            try {
                const res = await fetch("/api/usuarios");
                if (!res.ok) {
                    if (res.status === 403) {
                        throw new Error("Acesso restrito ao perfil GERENTE.");
                    }
                    throw new Error("Não foi possível carregar os usuários.");
                }
                const data = await res.json();
                if (!ignore) {
                    setUsuarios(data.usuarios || []);
                    setErroCarregamento(null);
                }
            }
            catch (err) {
                if (!ignore) {
                    setErroCarregamento(err instanceof Error ? err.message : "Erro desconhecido.");
                }
            }
            finally {
                if (!ignore) {
                    setCarregando(false);
                }
            }
        }
        init();
        return () => {
            ignore = true;
        };
    }, []);
    function abrirModal() {
        setNome("");
        setEmail("");
        setSenha("");
        setPerfil("FUNCIONARIO");
        setErrosForm({});
        setErroEnvio(null);
        setModalAberto(true);
    }
    function fecharModal() {
        setModalAberto(false);
        setErrosForm({});
        setErroEnvio(null);
    }
    async function handleSubmit(e) {
        e.preventDefault();
        setSalvando(true);
        setErrosForm({});
        setErroEnvio(null);
        try {
            const res = await fetch("/api/usuarios", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ nome, email, senha, perfil }),
            });
            const data = await res.json();
            if (res.status === 422 && data.erros) {
                const mapa = {};
                data.erros.forEach((err) => {
                    mapa[err.campo] = err.mensagem;
                });
                setErrosForm(mapa);
                return;
            }
            if (!res.ok) {
                setErroEnvio(data.erro || "Erro ao salvar usuário.");
                return;
            }
            setMensagemSucesso(`Usuário "${data.usuario.nome}" cadastrado com sucesso!`);
            fecharModal();
            await carregarUsuarios();
            setTimeout(() => setMensagemSucesso(null), 5000);
        }
        catch {
            setErroEnvio("Erro de conexão ao salvar usuário.");
        }
        finally {
            setSalvando(false);
        }
    }
    return (_jsxs("div", { children: [_jsxs("div", { style: {
                    marginBottom: "24px",
                    display: "flex",
                    alignItems: "flex-start",
                    justifyContent: "space-between",
                    gap: "16px",
                    flexWrap: "wrap",
                }, children: [_jsxs("div", { children: [_jsx("h1", { style: {
                                    margin: "0 0 4px",
                                    fontSize: "24px",
                                    fontWeight: 700,
                                    color: "var(--color-text)",
                                }, children: "Usu\u00E1rios" }), _jsx("p", { style: { margin: 0, fontSize: "14px", color: "var(--color-text-muted)" }, children: "Equipe, perfis e controle de acesso" })] }), _jsxs("button", { id: "btn-cadastrar-usuario", onClick: abrirModal, style: {
                            display: "flex",
                            alignItems: "center",
                            gap: "8px",
                            background: "var(--color-primary)",
                            color: "#fff",
                            border: "none",
                            borderRadius: "8px",
                            padding: "10px 20px",
                            fontSize: "14px",
                            fontWeight: 600,
                            cursor: "pointer",
                            transition: "background var(--transition)",
                            flexShrink: 0,
                        }, onMouseEnter: (e) => (e.currentTarget.style.background = "var(--color-primary-dark)"), onMouseLeave: (e) => (e.currentTarget.style.background = "var(--color-primary)"), children: [_jsx("span", { "aria-hidden": "true", children: "\uFF0B" }), " Novo usu\u00E1rio"] })] }), mensagemSucesso && (_jsxs("div", { role: "status", style: {
                    background: "#f0fdf4",
                    border: "1px solid #86efac",
                    borderRadius: "8px",
                    padding: "12px 16px",
                    marginBottom: "20px",
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    fontSize: "14px",
                    color: "#166534",
                    fontWeight: 500,
                }, children: [_jsx("span", { "aria-hidden": "true", children: "\u2705" }), mensagemSucesso] })), erroCarregamento && (_jsxs("div", { role: "alert", style: {
                    background: "#fef2f2",
                    border: "1px solid #fca5a5",
                    borderRadius: "8px",
                    padding: "16px",
                    color: "#991b1b",
                    fontSize: "14px",
                    marginBottom: "20px",
                }, children: [_jsx("strong", { children: "Acesso negado ou erro ao carregar:" }), " ", erroCarregamento] })), carregando && (_jsxs("div", { style: {
                    textAlign: "center",
                    padding: "48px 0",
                    color: "var(--color-text-muted)",
                }, children: [_jsx("span", { "aria-hidden": "true", style: { fontSize: "32px", display: "block", marginBottom: "12px" }, children: "\u23F3" }), "Carregando usu\u00E1rios..."] })), !carregando && !erroCarregamento && (_jsxs("div", { style: {
                    background: "var(--color-surface)",
                    border: "1.5px solid var(--color-border)",
                    borderRadius: "12px",
                    overflow: "hidden",
                    boxShadow: "var(--shadow-sm)",
                }, children: [_jsx("div", { style: { overflowX: "auto" }, children: _jsxs("table", { style: {
                                width: "100%",
                                borderCollapse: "collapse",
                                textAlign: "left",
                            }, children: [_jsx("thead", { children: _jsxs("tr", { style: {
                                            background: "var(--color-surface-2)",
                                            borderBottom: "1.5px solid var(--color-border)",
                                        }, children: [_jsx("th", { style: thStyle, children: "Nome" }), _jsx("th", { style: thStyle, children: "Email" }), _jsx("th", { style: thStyle, children: "Perfil" }), _jsx("th", { style: { ...thStyle, textAlign: "right" }, children: "Cadastrado em" })] }) }), _jsx("tbody", { children: usuarios.length === 0 ? (_jsx("tr", { children: _jsx("td", { colSpan: 4, style: {
                                                padding: "48px 18px",
                                                textAlign: "center",
                                                color: "var(--color-text-muted)",
                                                fontSize: "14px",
                                            }, children: "Nenhum usu\u00E1rio cadastrado ainda." }) })) : (usuarios.map((u, i) => (_jsxs("tr", { style: {
                                            borderBottom: i < usuarios.length - 1
                                                ? "1px solid var(--color-border)"
                                                : "none",
                                            transition: "background var(--transition)",
                                        }, onMouseEnter: (e) => (e.currentTarget.style.background =
                                            "var(--color-surface-2)"), onMouseLeave: (e) => (e.currentTarget.style.background = "transparent"), children: [_jsx("td", { style: {
                                                    padding: "14px 18px",
                                                    fontWeight: 600,
                                                    color: "var(--color-text)",
                                                    fontSize: "14px",
                                                }, children: u.nome }), _jsx("td", { style: {
                                                    padding: "14px 18px",
                                                    color: "var(--color-text-muted)",
                                                    fontSize: "14px",
                                                }, children: u.email }), _jsx("td", { style: { padding: "14px 18px" }, children: _jsx("span", { style: {
                                                        background: u.perfil === "GERENTE" ? "#e0e7ff" : "#f3f4f6",
                                                        color: u.perfil === "GERENTE" ? "#3730a3" : "#374151",
                                                        fontSize: "12px",
                                                        fontWeight: 700,
                                                        padding: "4px 10px",
                                                        borderRadius: "6px",
                                                        display: "inline-block",
                                                        letterSpacing: "0.04em",
                                                    }, children: u.perfil }) }), _jsx("td", { style: {
                                                    padding: "14px 18px",
                                                    textAlign: "right",
                                                    color: "var(--color-text-muted)",
                                                    fontSize: "13px",
                                                }, children: new Date(u.criadoEm).toLocaleDateString("pt-BR", {
                                                    day: "2-digit",
                                                    month: "2-digit",
                                                    year: "numeric",
                                                }) })] }, u.id)))) })] }) }), _jsxs("div", { style: {
                            padding: "12px 18px",
                            background: "var(--color-surface-2)",
                            borderTop: "1px solid var(--color-border)",
                            fontSize: "12px",
                            fontWeight: 500,
                            color: "var(--color-text-muted)",
                        }, children: [usuarios.length, " ", usuarios.length === 1 ? "usuário cadastrado" : "usuários cadastrados"] })] })), modalAberto && (_jsxs("div", { role: "dialog", "aria-modal": "true", "aria-labelledby": "modal-usuario-titulo", style: {
                    position: "fixed",
                    inset: 0,
                    zIndex: 1000,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    padding: "16px",
                }, children: [_jsx("div", { onClick: fecharModal, style: {
                            position: "absolute",
                            inset: 0,
                            background: "rgba(0,0,0,0.5)",
                            backdropFilter: "blur(2px)",
                        }, "aria-hidden": "true" }), _jsxs("div", { style: {
                            position: "relative",
                            background: "var(--color-surface)",
                            borderRadius: "16px",
                            width: "100%",
                            maxWidth: "500px",
                            boxShadow: "var(--shadow-lg)",
                            zIndex: 1,
                            maxHeight: "90dvh",
                            overflowY: "auto",
                        }, children: [_jsxs("div", { style: {
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "space-between",
                                    padding: "20px 24px",
                                    borderBottom: "1px solid var(--color-border)",
                                    position: "sticky",
                                    top: 0,
                                    background: "var(--color-surface)",
                                    zIndex: 2,
                                }, children: [_jsx("h2", { id: "modal-usuario-titulo", style: {
                                            margin: 0,
                                            fontSize: "18px",
                                            fontWeight: 700,
                                            color: "var(--color-text)",
                                        }, children: "Cadastrar novo usu\u00E1rio" }), _jsx("button", { type: "button", onClick: fecharModal, "aria-label": "Fechar modal", style: {
                                            background: "none",
                                            border: "none",
                                            fontSize: "20px",
                                            cursor: "pointer",
                                            color: "var(--color-text-muted)",
                                            lineHeight: 1,
                                        }, children: "\u2715" })] }), _jsxs("form", { onSubmit: handleSubmit, noValidate: true, style: { padding: "24px" }, children: [erroEnvio && (_jsx("div", { role: "alert", style: {
                                            background: "#fef2f2",
                                            border: "1px solid #fca5a5",
                                            borderRadius: "8px",
                                            padding: "12px",
                                            color: "#991b1b",
                                            fontSize: "13px",
                                            marginBottom: "16px",
                                        }, children: erroEnvio })), _jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "16px" }, children: [_jsxs("div", { children: [_jsx("label", { htmlFor: "usr-nome", style: labelStyle, children: "Nome completo *" }), _jsx("input", { id: "usr-nome", type: "text", value: nome, onChange: (e) => setNome(e.target.value), placeholder: "Ex: Ana Maria Souza", style: inputStyle, disabled: salvando }), errosForm.nome && (_jsx("p", { style: erroStyle, children: errosForm.nome }))] }), _jsxs("div", { children: [_jsx("label", { htmlFor: "usr-email", style: labelStyle, children: "Email de acesso *" }), _jsx("input", { id: "usr-email", type: "email", value: email, onChange: (e) => setEmail(e.target.value), placeholder: "exemplo@restaurante.com", style: inputStyle, disabled: salvando }), errosForm.email && (_jsx("p", { style: erroStyle, children: errosForm.email }))] }), _jsxs("div", { children: [_jsx("label", { htmlFor: "usr-perfil", style: labelStyle, children: "Perfil de acesso *" }), _jsxs("select", { id: "usr-perfil", value: perfil, onChange: (e) => setPerfil(e.target.value), style: inputStyle, disabled: salvando, children: [_jsx("option", { value: "FUNCIONARIO", children: "FUNCIONARIO (Estoque e opera\u00E7\u00F5es)" }), _jsx("option", { value: "GERENTE", children: "GERENTE (Acesso total)" })] }), errosForm.perfil && (_jsx("p", { style: erroStyle, children: errosForm.perfil }))] }), _jsxs("div", { children: [_jsx("label", { htmlFor: "usr-senha", style: labelStyle, children: "Senha de acesso *" }), _jsx("input", { id: "usr-senha", type: "password", value: senha, onChange: (e) => setSenha(e.target.value), placeholder: "M\u00EDnimo 6 caracteres", style: inputStyle, disabled: salvando, autoComplete: "new-password" }), errosForm.senha && (_jsx("p", { style: erroStyle, children: errosForm.senha })), _jsx("p", { style: {
                                                            margin: "4px 0 0",
                                                            fontSize: "11px",
                                                            color: "var(--color-text-light)",
                                                        }, children: "A senha ser\u00E1 armazenada usando hash criptogr\u00E1fico seguro (bcrypt)." })] })] }), _jsxs("div", { style: {
                                            display: "flex",
                                            justifyContent: "flex-end",
                                            gap: "12px",
                                            marginTop: "24px",
                                            paddingTop: "16px",
                                            borderTop: "1px solid var(--color-border)",
                                            flexWrap: "wrap",
                                        }, children: [_jsx("button", { type: "button", onClick: fecharModal, disabled: salvando, style: {
                                                    background: "none",
                                                    border: "1.5px solid var(--color-border)",
                                                    borderRadius: "8px",
                                                    padding: "10px 18px",
                                                    fontSize: "14px",
                                                    cursor: "pointer",
                                                    color: "var(--color-text-muted)",
                                                }, children: "Cancelar" }), _jsx("button", { id: "btn-salvar-usuario", type: "submit", disabled: salvando, style: {
                                                    background: salvando ? "#86efac" : "var(--color-primary)",
                                                    color: "#fff",
                                                    border: "none",
                                                    borderRadius: "8px",
                                                    padding: "10px 20px",
                                                    fontSize: "14px",
                                                    fontWeight: 600,
                                                    cursor: salvando ? "not-allowed" : "pointer",
                                                }, children: salvando ? "Salvando..." : "Cadastrar usuário" })] })] })] })] }))] }));
}
const thStyle = {
    padding: "14px 18px",
    fontSize: "12px",
    fontWeight: 700,
    color: "var(--color-text-muted)",
    textTransform: "uppercase",
    letterSpacing: "0.06em",
    whiteSpace: "nowrap",
};
const labelStyle = {
    display: "block",
    fontSize: "13px",
    fontWeight: 600,
    color: "var(--color-text)",
    marginBottom: "6px",
};
const inputStyle = {
    width: "100%",
    padding: "10px 12px",
    border: "1.5px solid var(--color-border)",
    borderRadius: "8px",
    fontSize: "14px",
    color: "var(--color-text)",
    background: "var(--color-surface)",
    boxSizing: "border-box",
    outline: "none",
};
const erroStyle = {
    margin: "4px 0 0",
    fontSize: "12px",
    color: "var(--color-danger)",
};
