"use client";
import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useCallback, useEffect, useState } from "react";
const hojeLocal = () => new Intl.DateTimeFormat("en-CA", { timeZone: "America/Manaus", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
const moeda = (valor) => new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(Number(valor));
const dataFmt = (valor) => {
    const [ano, mes, dia] = valor.slice(0, 10).split("-");
    return `${dia}/${mes}/${ano}`;
};
const inputStyle = { width: "100%", boxSizing: "border-box", border: "1px solid var(--color-border)", borderRadius: 8, padding: "10px 11px", fontSize: 14, background: "var(--color-surface)", color: "var(--color-text)" };
const buttonStyle = { border: 0, borderRadius: 8, padding: "10px 15px", background: "var(--color-primary)", color: "#fff", fontSize: 14, fontWeight: 650, cursor: "pointer" };
function mensagemErro(dados, padrao) {
    return dados.erro ?? dados.erros?.map((erro) => erro.mensagem).join(" ") ?? padrao;
}
export default function ComprasClient() {
    const [pedidos, setPedidos] = useState([]);
    const [produtos, setProdutos] = useState([]);
    const [carregando, setCarregando] = useState(true);
    const [erro, setErro] = useState("");
    const [statusFiltro, setStatusFiltro] = useState("TODOS");
    const [busca, setBusca] = useState("");
    const [fornecedor, setFornecedor] = useState("");
    const [dataPedido, setDataPedido] = useState(hojeLocal);
    const [observacoes, setObservacoes] = useState("");
    const [linhas, setLinhas] = useState([{ chave: 1, produtoId: "", quantidade: "", custoUnitario: "" }]);
    const [proximaChave, setProximaChave] = useState(2);
    const [salvando, setSalvando] = useState(false);
    const [recebendo, setRecebendo] = useState(null);
    const [cancelando, setCancelando] = useState(null);
    const [erroAcao, setErroAcao] = useState("");
    const [pedidoRecebimento, setPedidoRecebimento] = useState(null);
    const [dataEntrada, setDataEntrada] = useState(hojeLocal);
    const [validades, setValidades] = useState({});
    const carregar = useCallback(async () => {
        setCarregando(true);
        setErro("");
        try {
            const [resPedidos, resEstoque] = await Promise.all([fetch("/api/compras", { cache: "no-store" }), fetch("/api/estoque", { cache: "no-store" })]);
            if (!resPedidos.ok || !resEstoque.ok)
                throw new Error("Falha ao carregar dados.");
            const [dadosPedidos, dadosEstoque] = await Promise.all([resPedidos.json(), resEstoque.json()]);
            setPedidos(dadosPedidos.pedidos);
            setProdutos(dadosEstoque.produtos.map((produto) => ({ id: produto.id, nome: produto.nome, unidadeMedida: produto.unidadeMedida })));
        }
        catch {
            setErro("Não foi possível carregar compras ou produtos. Tente novamente.");
        }
        finally {
            setCarregando(false);
        }
    }, []);
    useEffect(() => {
        const timer = window.setTimeout(() => { void carregar(); }, 0);
        return () => window.clearTimeout(timer);
    }, [carregar]);
    function atualizarLinha(chave, campo, valor) {
        setLinhas((atuais) => atuais.map((linha) => linha.chave === chave ? { ...linha, [campo]: valor } : linha));
    }
    function adicionarLinha() {
        setLinhas((atuais) => [...atuais, { chave: proximaChave, produtoId: "", quantidade: "", custoUnitario: "" }]);
        setProximaChave((atual) => atual + 1);
    }
    async function criarPedido(evento) {
        evento.preventDefault();
        setSalvando(true);
        setErroAcao("");
        try {
            const resposta = await fetch("/api/compras", {
                method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ fornecedor, dataPedido, observacoes, itens: linhas.map(({ produtoId, quantidade, custoUnitario }) => ({ produtoId, quantidade, custoUnitario })) }),
            });
            const dados = await resposta.json();
            if (!resposta.ok)
                throw new Error(mensagemErro(dados, "Não foi possível criar o pedido."));
            setFornecedor("");
            setObservacoes("");
            setDataPedido(hojeLocal());
            setLinhas([{ chave: proximaChave, produtoId: "", quantidade: "", custoUnitario: "" }]);
            setProximaChave((atual) => atual + 1);
            await carregar();
        }
        catch (error) {
            setErroAcao(error instanceof Error ? error.message : "Não foi possível criar o pedido.");
        }
        finally {
            setSalvando(false);
        }
    }
    async function receberPedido(pedido) {
        if (!window.confirm(`Confirmar o recebimento integral dos ${pedido.itens.length} itens do pedido? Isso criará lotes no estoque.`))
            return;
        setRecebendo(pedido.id);
        setErroAcao("");
        try {
            const resposta = await fetch(`/api/compras/${pedido.id}/receber`, {
                method: "POST", headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ dataEntrada, itens: pedido.itens.map((item) => ({ itemId: item.id, dataValidade: validades[item.id] || null })) }),
            });
            const dados = await resposta.json();
            if (!resposta.ok)
                throw new Error(mensagemErro(dados, "Não foi possível receber o pedido."));
            setPedidoRecebimento(null);
            await carregar();
        }
        catch (error) {
            setErroAcao(error instanceof Error ? error.message : "Não foi possível receber o pedido.");
        }
        finally {
            setRecebendo(null);
        }
    }
    async function cancelarPedido(pedido) {
        if (!window.confirm("Cancelar este pedido pendente? O estoque não será movimentado."))
            return;
        setCancelando(pedido.id);
        setErroAcao("");
        try {
            const resposta = await fetch(`/api/compras/${pedido.id}/cancelar`, { method: "POST" });
            const dados = await resposta.json();
            if (!resposta.ok)
                throw new Error(mensagemErro(dados, "Não foi possível cancelar o pedido."));
            await carregar();
        }
        catch (error) {
            setErroAcao(error instanceof Error ? error.message : "Não foi possível cancelar o pedido.");
        }
        finally {
            setCancelando(null);
        }
    }
    const pedidosFiltrados = pedidos.filter((pedido) => {
        const termo = busca.trim().toLocaleLowerCase("pt-BR");
        const correspondeBusca = !termo || `${pedido.fornecedor ?? ""} ${pedido.itens.map((item) => item.produtoNome).join(" ")}`.toLocaleLowerCase("pt-BR").includes(termo);
        return (statusFiltro === "TODOS" || pedido.status === statusFiltro) && correspondeBusca;
    });
    return _jsxs("main", { style: { width: "100%", maxWidth: 1280, boxSizing: "border-box", margin: "0 auto", padding: "26px clamp(16px, 3vw, 32px)" }, children: [_jsxs("header", { style: { marginBottom: 22 }, children: [_jsx("h1", { style: { margin: 0, fontSize: 25, fontWeight: 750 }, children: "Compras" }), _jsx("p", { style: { margin: "6px 0 0", color: "var(--color-text-muted)", fontSize: 14 }, children: "Monte pedidos e receba todos os itens diretamente como lotes de estoque." })] }), erro && _jsxs("div", { role: "alert", style: { marginBottom: 16, padding: 14, borderRadius: 9, background: "#fef2f2", color: "#b91c1c", display: "flex", gap: 12, justifyContent: "space-between", flexWrap: "wrap" }, children: [erro, _jsx("button", { onClick: () => void carregar(), children: "Tentar novamente" })] }), erroAcao && _jsx("div", { role: "alert", style: { marginBottom: 16, padding: 14, borderRadius: 9, background: "#fef2f2", color: "#b91c1c" }, children: erroAcao }), _jsxs("section", { style: { background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 12, padding: "18px clamp(14px, 2vw, 24px)", marginBottom: 22 }, children: [_jsx("h2", { style: { fontSize: 18, margin: "0 0 16px" }, children: "Novo pedido" }), produtos.length === 0 && !carregando && _jsx("p", { style: { padding: 12, background: "#fffbeb", borderRadius: 8, color: "#92400e", fontSize: 13 }, children: "Cadastre um produto ativo no Estoque antes de montar um pedido." }), _jsxs("form", { onSubmit: criarPedido, children: [_jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 220px), 1fr))", gap: 12, marginBottom: 16 }, children: [_jsxs("label", { style: { fontSize: 13, fontWeight: 600 }, children: ["Fornecedor (opcional)", _jsx("input", { value: fornecedor, onChange: (e) => setFornecedor(e.target.value), maxLength: 200, placeholder: "Nome informado no pedido", style: { ...inputStyle, marginTop: 6, fontWeight: 400 } })] }), _jsxs("label", { style: { fontSize: 13, fontWeight: 600 }, children: ["Data do pedido", _jsx("input", { required: true, type: "date", value: dataPedido, onChange: (e) => setDataPedido(e.target.value), style: { ...inputStyle, marginTop: 6, fontWeight: 400 } })] }), _jsxs("label", { style: { fontSize: 13, fontWeight: 600 }, children: ["Observa\u00E7\u00F5es", _jsx("input", { value: observacoes, onChange: (e) => setObservacoes(e.target.value), maxLength: 500, placeholder: "Opcional", style: { ...inputStyle, marginTop: 6, fontWeight: 400 } })] })] }), _jsx("div", { style: { display: "grid", gap: 10 }, children: linhas.map((linha, index) => {
                                    const produto = produtos.find((p) => p.id === linha.produtoId);
                                    return _jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 170px), 1fr))", gap: 10, padding: 12, border: "1px solid var(--color-border)", borderRadius: 9 }, children: [_jsxs("label", { style: { fontSize: 12, fontWeight: 600 }, children: ["Produto ", index + 1, _jsxs("select", { required: true, value: linha.produtoId, onChange: (e) => atualizarLinha(linha.chave, "produtoId", e.target.value), style: { ...inputStyle, marginTop: 5, fontWeight: 400 }, children: [_jsx("option", { value: "", children: "Selecione" }), produtos.map((item) => _jsxs("option", { value: item.id, children: [item.nome, " (", item.unidadeMedida, ")"] }, item.id))] })] }), _jsxs("label", { style: { fontSize: 12, fontWeight: 600 }, children: ["Quantidade", produto ? ` (${produto.unidadeMedida})` : "", _jsx("input", { required: true, type: "number", min: "0.001", step: "0.001", value: linha.quantidade, onChange: (e) => atualizarLinha(linha.chave, "quantidade", e.target.value), style: { ...inputStyle, marginTop: 5, fontWeight: 400 } })] }), _jsxs("label", { style: { fontSize: 12, fontWeight: 600 }, children: ["Custo unit\u00E1rio (R$)", _jsx("input", { required: true, type: "number", min: "0", step: "0.01", value: linha.custoUnitario, onChange: (e) => atualizarLinha(linha.chave, "custoUnitario", e.target.value), style: { ...inputStyle, marginTop: 5, fontWeight: 400 } })] }), linhas.length > 1 && _jsx("button", { type: "button", onClick: () => setLinhas((atuais) => atuais.filter((item) => item.chave !== linha.chave)), style: { alignSelf: "end", padding: "10px 12px", borderRadius: 8, border: "1px solid #fecaca", color: "#b91c1c", background: "#fff", cursor: "pointer" }, children: "Remover item" })] }, linha.chave);
                                }) }), _jsxs("div", { style: { display: "flex", flexWrap: "wrap", gap: 10, justifyContent: "space-between", marginTop: 15 }, children: [_jsx("button", { type: "button", onClick: adicionarLinha, style: { border: "1px solid var(--color-border)", background: "transparent", color: "var(--color-text)", borderRadius: 8, padding: "9px 13px", cursor: "pointer" }, children: "+ Adicionar item" }), _jsx("button", { type: "submit", disabled: salvando || produtos.length === 0, style: { ...buttonStyle, opacity: salvando ? 0.7 : 1 }, children: salvando ? "Salvando pedido…" : "Criar pedido pendente" })] }), _jsx("p", { style: { margin: "10px 0 0", color: "var(--color-text-muted)", fontSize: 12 }, children: "O total \u00E9 calculado no servidor com base nos itens e arredondamento monet\u00E1rio por item." })] })] }), _jsxs("section", { children: [_jsxs("div", { style: { display: "flex", alignItems: "end", justifyContent: "space-between", gap: 12, flexWrap: "wrap", marginBottom: 13 }, children: [_jsx("h2", { style: { fontSize: 19, margin: 0 }, children: "Hist\u00F3rico de pedidos" }), _jsxs("div", { style: { display: "flex", gap: 8, flexWrap: "wrap" }, children: [_jsxs("label", { children: [_jsx("span", { className: "sr-only", children: "Filtrar por status" }), _jsxs("select", { value: statusFiltro, onChange: (e) => setStatusFiltro(e.target.value), style: { ...inputStyle, width: "auto", minWidth: 145 }, children: [_jsx("option", { value: "TODOS", children: "Todos os status" }), _jsx("option", { value: "PENDENTE", children: "Pendentes" }), _jsx("option", { value: "RECEBIDO", children: "Recebidos" }), _jsx("option", { value: "CANCELADO", children: "Cancelados" })] })] }), _jsx("input", { "aria-label": "Buscar fornecedor ou produto", placeholder: "Fornecedor ou produto", value: busca, onChange: (e) => setBusca(e.target.value), style: { ...inputStyle, width: "auto", minWidth: 190 } })] })] }), carregando && _jsx("p", { role: "status", style: { color: "var(--color-text-muted)" }, children: "Carregando pedidos\u2026" }), !carregando && !erro && pedidosFiltrados.length === 0 && _jsx("div", { style: { background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 10, padding: 25, textAlign: "center", color: "var(--color-text-muted)", fontSize: 14 }, children: pedidos.length ? "Nenhum pedido corresponde aos filtros." : "Ainda não há pedidos de compra." }), _jsx("div", { style: { display: "grid", gap: 12 }, children: pedidosFiltrados.map((pedido) => {
                            const corStatus = pedido.status === "PENDENTE" ? "#a16207" : pedido.status === "RECEBIDO" ? "#15803d" : "#64748b";
                            return _jsxs("article", { style: { background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 12, overflow: "hidden" }, children: [_jsxs("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "start", gap: 12, flexWrap: "wrap", padding: "15px 18px", borderBottom: "1px solid var(--color-border)" }, children: [_jsxs("div", { children: [_jsxs("div", { style: { display: "flex", alignItems: "center", flexWrap: "wrap", gap: 8 }, children: [_jsxs("strong", { children: ["Pedido ", pedido.id.slice(-8).toUpperCase()] }), _jsx("span", { style: { background: `${corStatus}18`, color: corStatus, borderRadius: 999, padding: "3px 9px", fontSize: 11, fontWeight: 750 }, children: pedido.status })] }), _jsxs("p", { style: { margin: "5px 0 0", color: "var(--color-text-muted)", fontSize: 13 }, children: [pedido.fornecedor || "Sem fornecedor informado", " \u00B7 Pedido em ", dataFmt(pedido.dataPedido)] })] }), _jsxs("div", { style: { textAlign: "right" }, children: [_jsx("strong", { style: { fontSize: 18 }, children: moeda(pedido.total) }), _jsxs("div", { style: { fontSize: 12, color: "var(--color-text-muted)" }, children: [pedido.itens.length, " ", pedido.itens.length === 1 ? "item" : "itens"] })] })] }), _jsx("div", { style: { padding: "4px 18px" }, children: pedido.itens.map((item) => _jsxs("div", { style: { display: "grid", gridTemplateColumns: "minmax(0, 1fr) auto", gap: "4px 12px", padding: "10px 0", borderBottom: "1px solid var(--color-border)", fontSize: 13 }, children: [_jsx("strong", { children: item.produtoNome }), _jsx("strong", { style: { textAlign: "right" }, children: moeda(item.total) }), _jsxs("span", { style: { color: "var(--color-text-muted)" }, children: [item.quantidade, " ", item.unidadeMedida, " \u00D7 ", moeda(item.custoUnitario), item.dataValidade ? ` · validade ${dataFmt(item.dataValidade)}` : ""] }), _jsx("span", {})] }, item.id)) }), pedido.observacoes && _jsxs("p", { style: { margin: 0, padding: "5px 18px 12px", color: "var(--color-text-muted)", fontSize: 13 }, children: ["Observa\u00E7\u00F5es: ", pedido.observacoes] }), pedido.status === "PENDENTE" && _jsxs("div", { style: { padding: "12px 18px", display: "flex", flexWrap: "wrap", gap: 9, borderTop: "1px solid var(--color-border)" }, children: [_jsx("button", { onClick: () => { setPedidoRecebimento(pedidoRecebimento === pedido.id ? null : pedido.id); setDataEntrada(hojeLocal()); setValidades({}); }, style: buttonStyle, children: "Receber pedido completo" }), _jsx("button", { disabled: cancelando === pedido.id, onClick: () => void cancelarPedido(pedido), style: { border: "1px solid #fecaca", borderRadius: 8, padding: "9px 13px", background: "#fff", color: "#b91c1c", fontWeight: 600, cursor: "pointer" }, children: cancelando === pedido.id ? "Cancelando…" : "Cancelar pedido" })] }), pedido.status === "PENDENTE" && pedidoRecebimento === pedido.id && _jsxs("div", { style: { padding: 16, background: "#f8fafc", borderTop: "1px solid var(--color-border)" }, children: [_jsx("h3", { style: { fontSize: 15, margin: "0 0 10px" }, children: "Receber todos os itens" }), _jsxs("label", { style: { display: "block", maxWidth: 260, marginBottom: 12, fontSize: 13, fontWeight: 600 }, children: ["Data de entrada", _jsx("input", { type: "date", required: true, value: dataEntrada, onChange: (e) => setDataEntrada(e.target.value), style: { ...inputStyle, marginTop: 5 } })] }), _jsx("div", { style: { display: "grid", gap: 8 }, children: pedido.itens.map((item) => _jsxs("label", { style: { display: "grid", gridTemplateColumns: "minmax(0, 1fr) minmax(150px, 220px)", gap: 10, alignItems: "center", padding: 10, background: "#fff", borderRadius: 8, fontSize: 13 }, children: [_jsxs("span", { children: [item.produtoNome, _jsxs("small", { style: { display: "block", color: "var(--color-text-muted)" }, children: [item.quantidade, " ", item.unidadeMedida] })] }), _jsxs("span", { children: ["Validade (opcional)", _jsx("input", { type: "date", value: validades[item.id] ?? "", onChange: (e) => setValidades((atual) => ({ ...atual, [item.id]: e.target.value })), style: { ...inputStyle, marginTop: 4 } })] })] }, item.id)) }), _jsxs("div", { style: { display: "flex", gap: 9, justifyContent: "end", marginTop: 12 }, children: [_jsx("button", { onClick: () => setPedidoRecebimento(null), disabled: recebendo === pedido.id, style: { padding: "9px 13px", border: "1px solid var(--color-border)", borderRadius: 8, background: "transparent", cursor: "pointer" }, children: "Voltar" }), _jsx("button", { onClick: () => void receberPedido(pedido), disabled: recebendo === pedido.id, style: { ...buttonStyle, opacity: recebendo === pedido.id ? 0.7 : 1 }, children: recebendo === pedido.id ? "Recebendo…" : "Confirmar recebimento integral" })] })] })] }, pedido.id);
                        }) }), !carregando && pedidos.length >= 200 && _jsx("p", { style: { color: "var(--color-text-muted)", fontSize: 12, textAlign: "center", marginTop: 14 }, children: "Exibindo os 200 pedidos mais recentes." })] })] });
}
