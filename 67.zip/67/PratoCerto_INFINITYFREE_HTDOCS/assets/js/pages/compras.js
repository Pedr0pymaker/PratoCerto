import { jsx as _jsx } from "react/jsx-runtime";
import ComprasClient from "/assets/js/pages/comprasClient.js";
export const metadata = {
    title: "Compras — PratoCerto",
    description: "Crie pedidos de compra e receba os itens diretamente no estoque.",
};
export default function ComprasPage() {
    return _jsx(ComprasClient, {});
}
