import { jsx as _jsx } from "react/jsx-runtime";
import EstoqueClient from "/assets/js/pages/estoqueClient.js";
export const metadata = {
    title: "Estoque — PratoCerto",
    description: "Controle de estoque e cadastro de produtos.",
};
export default function EstoquePage() {
    return _jsx(EstoqueClient, {});
}
