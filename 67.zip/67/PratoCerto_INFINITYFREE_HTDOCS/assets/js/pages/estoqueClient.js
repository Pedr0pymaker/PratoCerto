"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useState, useEffect, useCallback } from "react";
const FORM_PRODUTO_INICIAL = {
    nome: "",
    categoria: "",
    unidadeMedida: "",
    estoqueMinimo: "",
    estoqueIdeal: "",
    custoReferencia: "",
};
const FORM_ENTRADA_INICIAL = {
    produtoId: "",
    quantidade: "",
    dataEntrada: new Date().toISOString().split("T")[0],
    dataValidade: "",
    custoUnitario: "",
};
const CATEGORIAS_COMUNS = [
    "Carnes e Aves",
    "Laticínios",
    "Hortifrúti",
    "Grãos e Cereais",
    "Bebidas",
    "Temperos e Condimentos",
    "Panificados",
    "Congelados",
    "Limpeza",
    "Descartáveis",
    "Outros",
];
const UNIDADES_COMUNS = [
    "kg",
    "g",
    "L",
    "mL",
    "un",
    "cx",
    "pct",
    "dz",
    "fardo",
];
// ---------------------------------------------------------------
// Componente principal
// ---------------------------------------------------------------
export default function EstoqueClient() {
    const [abaAtiva, setAbaAtiva] = useState("estoque");
    const [produtos, setProdutos] = useState([]);
    const [carregando, setCarregando] = useState(true);
    const [erroCarregamento, setErroCarregamento] = useState(null);
    // Modal Cadastro de Produto
    const [modalProdutoAberto, setModalProdutoAberto] = useState(false);
    const [formProduto, setFormProduto] = useState(FORM_PRODUTO_INICIAL);
    const [errosProduto, setErrosProduto] = useState({});
    const [salvandoProduto, setSalvandoProduto] = useState(false);
    // Modal Entrada de Estoque
    const [modalEntradaAberto, setModalEntradaAberto] = useState(false);
    const [formEntrada, setFormEntrada] = useState(FORM_ENTRADA_INICIAL);
    const [errosEntrada, setErrosEntrada] = useState({});
    const [salvandoEntrada, setSalvandoEntrada] = useState(false);
    // Lotes expandidos por ID do produto
    const [lotesExpandidos, setLotesExpandidos] = useState({});
    // Mensagens globais
    const [mensagemSucesso, setMensagemSucesso] = useState(null);
    const [erroEnvio, setErroEnvio] = useState(null);
    const [busca, setBusca] = useState("");
    // -------------------------------------------------------------------
    // Carregar dados de estoque (produtos + lotes + saldos)
    // -------------------------------------------------------------------
    const carregarDados = useCallback(async () => {
        try {
            const res = await fetch("/api/estoque");
            if (!res.ok)
                throw new Error(`Erro ${res.status}`);
            const data = await res.json();
            setProdutos(data.produtos ?? []);
            setErroCarregamento(null);
        }
        catch {
            setErroCarregamento("Não foi possível carregar o estoque. Verifique a conexão com o banco de dados.");
        }
        finally {
            setCarregando(false);
        }
    }, []);
    useEffect(() => {
        let ignore = false;
        async function init() {
            try {
                const res = await fetch("/api/estoque");
                if (!res.ok)
                    throw new Error(`Erro ${res.status}`);
                const data = await res.json();
                if (!ignore) {
                    setProdutos(data.produtos ?? []);
                    setErroCarregamento(null);
                }
            }
            catch {
                if (!ignore) {
                    setErroCarregamento("Não foi possível carregar o estoque. Verifique a conexão com o banco de dados.");
                }
            }
            finally {
                if (!ignore) {
                    setCarregando(false);
                }
            }
        }
        init();
        return () => {
            ignore = true;
        };
    }, []);
    // -------------------------------------------------------------------
    // Produtos filtrados pela busca
    // -------------------------------------------------------------------
    const produtosFiltrados = produtos.filter((p) => {
        const q = busca.toLowerCase();
        return (p.nome.toLowerCase().includes(q) ||
            p.categoria.toLowerCase().includes(q) ||
            p.unidadeMedida.toLowerCase().includes(q));
    });
    // Toggle expansão de lotes
    function toggleLotes(produtoId) {
        setLotesExpandidos((prev) => ({
            ...prev,
            [produtoId]: !prev[produtoId],
        }));
    }
    // -------------------------------------------------------------------
    // Ações de Entrada de Estoque
    // -------------------------------------------------------------------
    function abrirModalEntrada(produtoIdPreSelecionado) {
        setFormEntrada({
            ...FORM_ENTRADA_INICIAL,
            produtoId: produtoIdPreSelecionado || (produtos[0]?.id ?? ""),
            dataEntrada: new Date().toISOString().split("T")[0],
        });
        setErrosEntrada({});
        setErroEnvio(null);
        setModalEntradaAberto(true);
    }
    function fecharModalEntrada() {
        setModalEntradaAberto(false);
        setFormEntrada(FORM_ENTRADA_INICIAL);
        setErrosEntrada({});
        setErroEnvio(null);
    }
    function handleChangeEntrada(e) {
        const { name, value } = e.target;
        setFormEntrada((prev) => ({ ...prev, [name]: value }));
        if (errosEntrada[name]) {
            setErrosEntrada((prev) => {
                const novo = { ...prev };
                delete novo[name];
                return novo;
            });
        }
    }
    async function handleSubmitEntrada(e) {
        e.preventDefault();
        setSalvandoEntrada(true);
        setErrosEntrada({});
        setErroEnvio(null);
        setMensagemSucesso(null);
        try {
            const payload = {
                produtoId: formEntrada.produtoId,
                quantidade: formEntrada.quantidade === "" ? "" : Number(formEntrada.quantidade),
                dataEntrada: formEntrada.dataEntrada,
                dataValidade: formEntrada.dataValidade || null,
                custoUnitario: formEntrada.custoUnitario === "" ? null : Number(formEntrada.custoUnitario),
            };
            const res = await fetch("/api/estoque", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });
            const data = await res.json();
            if (res.status === 422 && data.erros) {
                const mapa = {};
                data.erros.forEach((err) => {
                    mapa[err.campo] = err.mensagem;
                });
                setErrosEntrada(mapa);
                return;
            }
            if (!res.ok) {
                setErroEnvio(data.erro ?? "Erro ao registrar entrada de estoque.");
                return;
            }
            const prodNome = produtos.find((p) => p.id === formEntrada.produtoId)?.nome || "Produto";
            setMensagemSucesso(`Entrada de ${formEntrada.quantidade} para "${prodNome}" registrada com sucesso!`);
            fecharModalEntrada();
            await carregarDados();
            // Expande automaticamente os lotes do produto que recebeu entrada
            if (formEntrada.produtoId) {
                setLotesExpandidos((prev) => ({ ...prev, [formEntrada.produtoId]: true }));
            }
            setTimeout(() => setMensagemSucesso(null), 5000);
        }
        catch {
            setErroEnvio("Erro de conexão. Verifique sua rede e tente novamente.");
        }
        finally {
            setSalvandoEntrada(false);
        }
    }
    // -------------------------------------------------------------------
    // Ações de Cadastro de Produto (preservado da Etapa 2)
    // -------------------------------------------------------------------
    function abrirModalProduto() {
        setFormProduto(FORM_PRODUTO_INICIAL);
        setErrosProduto({});
        setErroEnvio(null);
        setModalProdutoAberto(true);
    }
    function fecharModalProduto() {
        setModalProdutoAberto(false);
        setFormProduto(FORM_PRODUTO_INICIAL);
        setErrosProduto({});
        setErroEnvio(null);
    }
    function handleChangeProduto(e) {
        const { name, value } = e.target;
        setFormProduto((prev) => ({ ...prev, [name]: value }));
        if (errosProduto[name]) {
            setErrosProduto((prev) => {
                const novo = { ...prev };
                delete novo[name];
                return novo;
            });
        }
    }
    async function handleSubmitProduto(e) {
        e.preventDefault();
        setSalvandoProduto(true);
        setErrosProduto({});
        setErroEnvio(null);
        setMensagemSucesso(null);
        try {
            const payload = {
                nome: formProduto.nome,
                categoria: formProduto.categoria,
                unidadeMedida: formProduto.unidadeMedida,
                estoqueMinimo: formProduto.estoqueMinimo === "" ? "" : Number(formProduto.estoqueMinimo),
                estoqueIdeal: formProduto.estoqueIdeal === "" ? "" : Number(formProduto.estoqueIdeal),
                custoReferencia: formProduto.custoReferencia === "" ? null : Number(formProduto.custoReferencia),
            };
            const res = await fetch("/api/produtos", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            });
            const data = await res.json();
            if (res.status === 422 && data.erros) {
                const mapa = {};
                data.erros.forEach((err) => {
                    mapa[err.campo] = err.mensagem;
                });
                setErrosProduto(mapa);
                return;
            }
            if (!res.ok) {
                setErroEnvio(data.erro ?? "Erro ao salvar produto. Tente novamente.");
                return;
            }
            setMensagemSucesso(`Produto "${data.produto.nome}" cadastrado com sucesso!`);
            fecharModalProduto();
            await carregarDados();
            setTimeout(() => setMensagemSucesso(null), 5000);
        }
        catch {
            setErroEnvio("Erro de conexão. Verifique sua rede e tente novamente.");
        }
        finally {
            setSalvandoProduto(false);
        }
    }
    // Estatísticas rápidas
    const totalProdutos = produtos.length;
    const produtosAbaixoMinimo = produtos.filter((p) => p.situacao === "ABAIXO_MINIMO").length;
    const totalLotes = produtos.reduce((acc, p) => acc + p.lotes.length, 0);
    return (_jsxs("div", { children: [_jsxs("div", { style: {
                    marginBottom: "24px",
                    display: "flex",
                    alignItems: "flex-start",
                    justifyContent: "space-between",
                    gap: "16px",
                    flexWrap: "wrap",
                }, children: [_jsxs("div", { children: [_jsx("h1", { style: { margin: "0 0 4px", fontSize: "24px", fontWeight: 700, color: "var(--color-text)" }, children: "Controle de Estoque & Lotes" }), _jsx("p", { style: { margin: 0, fontSize: "14px", color: "var(--color-text-muted)" }, children: "Gerenciamento de entradas de mercadorias, lotes FIFO e saldos dispon\u00EDveis" })] }), _jsxs("div", { style: { display: "flex", gap: "10px", flexWrap: "wrap" }, children: [_jsxs("button", { id: "btn-registrar-entrada", onClick: () => abrirModalEntrada(), style: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "8px",
                                    background: "var(--color-primary)",
                                    color: "#fff",
                                    border: "none",
                                    borderRadius: "8px",
                                    padding: "10px 18px",
                                    fontSize: "14px",
                                    fontWeight: 600,
                                    cursor: "pointer",
                                    boxShadow: "0 2px 6px rgba(16, 185, 129, 0.25)",
                                    transition: "background var(--transition)",
                                }, children: [_jsx("span", { "aria-hidden": "true", children: "\uD83D\uDCE5" }), " Registrar entrada"] }), _jsxs("button", { id: "btn-cadastrar-produto", onClick: abrirModalProduto, style: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "8px",
                                    background: "var(--color-surface)",
                                    color: "var(--color-text)",
                                    border: "1.5px solid var(--color-border)",
                                    borderRadius: "8px",
                                    padding: "10px 18px",
                                    fontSize: "14px",
                                    fontWeight: 600,
                                    cursor: "pointer",
                                    transition: "all var(--transition)",
                                }, children: [_jsx("span", { "aria-hidden": "true", children: "\uFF0B" }), " Novo produto"] })] })] }), _jsxs("div", { style: {
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: "16px",
                    marginBottom: "24px",
                }, children: [_jsxs("div", { style: {
                            background: "var(--color-surface)",
                            border: "1px solid var(--color-border)",
                            borderRadius: "10px",
                            padding: "16px",
                            boxShadow: "var(--shadow-sm)",
                        }, children: [_jsx("span", { style: { fontSize: "12px", fontWeight: 600, color: "var(--color-text-muted)", textTransform: "uppercase" }, children: "Produtos Ativos" }), _jsx("div", { style: { fontSize: "24px", fontWeight: 700, color: "var(--color-text)", marginTop: "4px" }, children: totalProdutos })] }), _jsxs("div", { style: {
                            background: "var(--color-surface)",
                            border: "1px solid var(--color-border)",
                            borderRadius: "10px",
                            padding: "16px",
                            boxShadow: "var(--shadow-sm)",
                        }, children: [_jsx("span", { style: { fontSize: "12px", fontWeight: 600, color: "var(--color-text-muted)", textTransform: "uppercase" }, children: "Lotes em Estoque" }), _jsx("div", { style: { fontSize: "24px", fontWeight: 700, color: "var(--color-text)", marginTop: "4px" }, children: totalLotes })] }), _jsxs("div", { style: {
                            background: produtosAbaixoMinimo > 0 ? "#fffbeb" : "var(--color-surface)",
                            border: `1px solid ${produtosAbaixoMinimo > 0 ? "#fcd34d" : "var(--color-border)"}`,
                            borderRadius: "10px",
                            padding: "16px",
                            boxShadow: "var(--shadow-sm)",
                        }, children: [_jsx("span", { style: {
                                    fontSize: "12px",
                                    fontWeight: 600,
                                    color: produtosAbaixoMinimo > 0 ? "#b45309" : "var(--color-text-muted)",
                                    textTransform: "uppercase",
                                }, children: "Abaixo do M\u00EDnimo" }), _jsx("div", { style: {
                                    fontSize: "24px",
                                    fontWeight: 700,
                                    color: produtosAbaixoMinimo > 0 ? "#d97706" : "var(--color-text)",
                                    marginTop: "4px",
                                }, children: produtosAbaixoMinimo })] })] }), mensagemSucesso && (_jsxs("div", { role: "status", "aria-live": "polite", style: {
                    background: "#f0fdf4",
                    border: "1px solid #86efac",
                    borderRadius: "8px",
                    padding: "12px 16px",
                    marginBottom: "20px",
                    display: "flex",
                    alignItems: "center",
                    gap: "10px",
                    fontSize: "14px",
                    color: "#166534",
                }, children: [_jsx("span", { "aria-hidden": "true", children: "\u2705" }), mensagemSucesso] })), _jsxs("div", { style: {
                    display: "flex",
                    borderBottom: "1.5px solid var(--color-border)",
                    marginBottom: "20px",
                    gap: "8px",
                }, children: [_jsx("button", { onClick: () => setAbaAtiva("estoque"), style: {
                            padding: "10px 18px",
                            background: "none",
                            border: "none",
                            borderBottom: abaAtiva === "estoque" ? "2.5px solid var(--color-primary)" : "2.5px solid transparent",
                            fontWeight: abaAtiva === "estoque" ? 700 : 500,
                            color: abaAtiva === "estoque" ? "var(--color-primary)" : "var(--color-text-muted)",
                            fontSize: "14px",
                            cursor: "pointer",
                            transition: "all var(--transition)",
                        }, children: "\uD83D\uDCE6 Saldo & Lotes de Estoque" }), _jsx("button", { onClick: () => setAbaAtiva("produtos"), style: {
                            padding: "10px 18px",
                            background: "none",
                            border: "none",
                            borderBottom: abaAtiva === "produtos" ? "2.5px solid var(--color-primary)" : "2.5px solid transparent",
                            fontWeight: abaAtiva === "produtos" ? 700 : 500,
                            color: abaAtiva === "produtos" ? "var(--color-primary)" : "var(--color-text-muted)",
                            fontSize: "14px",
                            cursor: "pointer",
                            transition: "all var(--transition)",
                        }, children: "\uD83D\uDCCB Cat\u00E1logo de Produtos" })] }), _jsx("div", { style: { marginBottom: "16px" }, children: _jsx("input", { id: "busca-produto", type: "search", placeholder: "Buscar produto por nome, categoria ou unidade...", value: busca, onChange: (e) => setBusca(e.target.value), style: estiloInput, "aria-label": "Buscar produto por nome, categoria ou unidade de medida" }) }), carregando && (_jsxs("div", { style: { textAlign: "center", padding: "48px 0", color: "var(--color-text-muted)" }, children: [_jsx("span", { "aria-hidden": "true", style: { fontSize: "32px", display: "block", marginBottom: "12px" }, children: "\u23F3" }), "Carregando informa\u00E7\u00F5es de estoque..."] })), !carregando && erroCarregamento && (_jsxs("div", { role: "alert", style: {
                    background: "#fef2f2",
                    border: "1px solid #fca5a5",
                    borderRadius: "8px",
                    padding: "16px",
                    color: "#991b1b",
                    fontSize: "14px",
                }, children: [_jsx("strong", { children: "Erro ao carregar dados" }), _jsx("br", {}), erroCarregamento, _jsx("br", {}), _jsx("button", { onClick: carregarDados, style: {
                            marginTop: "10px",
                            color: "#dc2626",
                            background: "none",
                            border: "1px solid #dc2626",
                            borderRadius: "6px",
                            padding: "6px 14px",
                            cursor: "pointer",
                            fontSize: "13px",
                        }, children: "Tentar novamente" })] })), !carregando && !erroCarregamento && (_jsx(_Fragment, { children: produtosFiltrados.length === 0 ? (_jsx(EstadoVazio, { busca: busca, onCadastrar: abrirModalProduto })) : abaAtiva === "estoque" ? (_jsx(TabelaEstoqueLotes, { produtos: produtosFiltrados, lotesExpandidos: lotesExpandidos, onToggleLotes: toggleLotes, onNovaEntrada: abrirModalEntrada })) : (_jsx(TabelaCatalogoProdutos, { produtos: produtosFiltrados })) })), modalEntradaAberto && (_jsx(ModalEntradaEstoque, { form: formEntrada, produtos: produtos, erros: errosEntrada, erroEnvio: erroEnvio, salvando: salvandoEntrada, onChange: handleChangeEntrada, onSubmit: handleSubmitEntrada, onFechar: fecharModalEntrada })), modalProdutoAberto && (_jsx(ModalCadastroProduto, { form: formProduto, erros: errosProduto, erroEnvio: erroEnvio, salvando: salvandoProduto, onChange: handleChangeProduto, onSubmit: handleSubmitProduto, onFechar: fecharModalProduto }))] }));
}
// ---------------------------------------------------------------
// Visualização de Estoque & Lotes (Etapa 4)
// ---------------------------------------------------------------
function TabelaEstoqueLotes({ produtos, lotesExpandidos, onToggleLotes, onNovaEntrada, }) {
    return (_jsx("div", { style: { display: "flex", flexDirection: "column", gap: "14px" }, children: produtos.map((p) => {
            const expandido = !!lotesExpandidos[p.id];
            const isAbaixoMinimo = p.situacao === "ABAIXO_MINIMO";
            return (_jsxs("div", { style: {
                    background: "var(--color-surface)",
                    border: `1.5px solid ${isAbaixoMinimo ? "#fcd34d" : "var(--color-border)"}`,
                    borderRadius: "12px",
                    boxShadow: "var(--shadow-sm)",
                    overflow: "hidden",
                }, children: [_jsxs("div", { style: {
                            padding: "16px 20px",
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            flexWrap: "wrap",
                            gap: "12px",
                            background: isAbaixoMinimo ? "#fffdf5" : "transparent",
                        }, children: [_jsx("div", { style: { display: "flex", alignItems: "center", gap: "12px", flexWrap: "wrap" }, children: _jsxs("div", { children: [_jsxs("div", { style: { display: "flex", alignItems: "center", gap: "8px" }, children: [_jsx("strong", { style: { fontSize: "16px", color: "var(--color-text)" }, children: p.nome }), _jsx("span", { style: {
                                                        background: "#f0fdf4",
                                                        color: "#166534",
                                                        fontSize: "12px",
                                                        padding: "2px 8px",
                                                        borderRadius: "6px",
                                                        fontWeight: 600,
                                                    }, children: p.categoria })] }), _jsxs("div", { style: { fontSize: "13px", color: "var(--color-text-muted)", marginTop: "2px" }, children: ["M\u00EDnimo:", " ", _jsxs("strong", { children: [p.estoqueMinimo, " ", p.unidadeMedida] }), " ", "| Ideal: ", p.estoqueIdeal, " ", p.unidadeMedida] })] }) }), _jsxs("div", { style: { display: "flex", alignItems: "center", gap: "16px", flexWrap: "wrap" }, children: [_jsxs("div", { style: { textAlign: "right" }, children: [_jsx("div", { style: { fontSize: "11px", textTransform: "uppercase", fontWeight: 600, color: "var(--color-text-muted)" }, children: "Saldo dispon\u00EDvel" }), _jsxs("div", { style: {
                                                    fontSize: "18px",
                                                    fontWeight: 700,
                                                    color: isAbaixoMinimo ? "#dc2626" : "#059669",
                                                    fontVariantNumeric: "tabular-nums",
                                                }, children: [p.saldoDisponivel.toLocaleString("pt-BR"), " ", p.unidadeMedida] })] }), _jsx("div", { children: isAbaixoMinimo ? (_jsxs("span", { style: {
                                                background: "#fef2f2",
                                                color: "#dc2626",
                                                border: "1px solid #fecaca",
                                                fontSize: "12px",
                                                padding: "5px 10px",
                                                borderRadius: "20px",
                                                fontWeight: 700,
                                                display: "inline-flex",
                                                alignItems: "center",
                                                gap: "4px",
                                            }, children: [_jsx("span", { "aria-hidden": "true", children: "\u26A0\uFE0F" }), " Abaixo do m\u00EDnimo"] })) : (_jsxs("span", { style: {
                                                background: "#ecfdf5",
                                                color: "#059669",
                                                border: "1px solid #a7f3d0",
                                                fontSize: "12px",
                                                padding: "5px 10px",
                                                borderRadius: "20px",
                                                fontWeight: 600,
                                                display: "inline-flex",
                                                alignItems: "center",
                                                gap: "4px",
                                            }, children: [_jsx("span", { "aria-hidden": "true", children: "\u2713" }), " Normal"] })) }), _jsxs("div", { style: { display: "flex", gap: "8px" }, children: [_jsx("button", { onClick: () => onNovaEntrada(p.id), title: "Registrar nova entrada para este produto", style: {
                                                    background: "var(--color-primary-light, #ecfdf5)",
                                                    color: "var(--color-primary-dark, #065f46)",
                                                    border: "1px solid var(--color-primary)",
                                                    borderRadius: "6px",
                                                    padding: "6px 12px",
                                                    fontSize: "13px",
                                                    fontWeight: 600,
                                                    cursor: "pointer",
                                                }, children: "+ Entrada" }), _jsxs("button", { onClick: () => onToggleLotes(p.id), "aria-expanded": expandido, style: {
                                                    background: "var(--color-surface-2)",
                                                    border: "1px solid var(--color-border)",
                                                    borderRadius: "6px",
                                                    padding: "6px 12px",
                                                    fontSize: "13px",
                                                    fontWeight: 500,
                                                    cursor: "pointer",
                                                    display: "flex",
                                                    alignItems: "center",
                                                    gap: "6px",
                                                    color: "var(--color-text)",
                                                }, children: [_jsxs("span", { children: ["Lotes (", p.lotes.length, ")"] }), _jsx("span", { style: { fontSize: "11px" }, children: expandido ? "▲" : "▼" })] })] })] })] }), expandido && (_jsx("div", { style: {
                            borderTop: "1px solid var(--color-border)",
                            background: "var(--color-surface-2)",
                            padding: "16px 20px",
                        }, children: p.lotes.length === 0 ? (_jsxs("div", { style: {
                                padding: "16px",
                                background: "var(--color-surface)",
                                borderRadius: "8px",
                                border: "1px dashed var(--color-border)",
                                color: "var(--color-text-muted)",
                                fontSize: "14px",
                                textAlign: "center",
                            }, children: [_jsx("span", { "aria-hidden": "true", style: { fontSize: "20px", display: "block", marginBottom: "4px" }, children: "\uD83D\uDCE6" }), "Nenhum lote registrado para este produto. Saldo dispon\u00EDvel: ", _jsxs("strong", { children: ["0 ", p.unidadeMedida] }), ".", _jsx("div", { style: { marginTop: "8px" }, children: _jsx("button", { onClick: () => onNovaEntrada(p.id), style: {
                                            background: "var(--color-primary)",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "6px",
                                            padding: "6px 14px",
                                            fontSize: "13px",
                                            fontWeight: 600,
                                            cursor: "pointer",
                                        }, children: "Registrar primeira entrada" }) })] })) : (_jsxs("div", { children: [_jsx("div", { style: {
                                        fontSize: "13px",
                                        fontWeight: 700,
                                        color: "var(--color-text)",
                                        marginBottom: "10px",
                                        display: "flex",
                                        alignItems: "center",
                                        gap: "6px",
                                    }, children: _jsx("span", { children: "Lotes dispon\u00EDveis para movimenta\u00E7\u00E3o (Ordem FIFO / Validade):" }) }), _jsx("div", { style: { overflowX: "auto" }, children: _jsxs("table", { style: { width: "100%", borderCollapse: "collapse", fontSize: "13px" }, children: [_jsx("thead", { children: _jsxs("tr", { style: { borderBottom: "1.5px solid var(--color-border)", textAlign: "left" }, children: [_jsx("th", { style: { padding: "8px 12px", color: "var(--color-text-muted)", fontWeight: 600 }, children: "ID Lote" }), _jsx("th", { style: { padding: "8px 12px", color: "var(--color-text-muted)", fontWeight: 600 }, children: "Entrada" }), _jsx("th", { style: { padding: "8px 12px", color: "var(--color-text-muted)", fontWeight: 600 }, children: "Validade" }), _jsx("th", { style: { padding: "8px 12px", textAlign: "right", color: "var(--color-text-muted)", fontWeight: 600 }, children: "Qtd. Inicial" }), _jsx("th", { style: { padding: "8px 12px", textAlign: "right", color: "var(--color-text-muted)", fontWeight: 600 }, children: "Qtd. Dispon\u00EDvel" }), _jsx("th", { style: { padding: "8px 12px", textAlign: "right", color: "var(--color-text-muted)", fontWeight: 600 }, children: "Custo Unit." })] }) }), _jsx("tbody", { children: p.lotes.map((lote) => {
                                                    const dataEntradaFmt = new Date(lote.dataEntrada).toLocaleDateString("pt-BR");
                                                    const dataValidadeFmt = lote.dataValidade
                                                        ? new Date(lote.dataValidade).toLocaleDateString("pt-BR")
                                                        : "—";
                                                    return (_jsxs("tr", { style: {
                                                            borderBottom: "1px solid var(--color-border)",
                                                            background: "var(--color-surface)",
                                                        }, children: [_jsxs("td", { style: { padding: "8px 12px", fontFamily: "monospace", fontSize: "12px", color: "var(--color-text-muted)" }, children: ["#", lote.id.slice(-6)] }), _jsx("td", { style: { padding: "8px 12px", whiteSpace: "nowrap" }, children: dataEntradaFmt }), _jsx("td", { style: { padding: "8px 12px", whiteSpace: "nowrap" }, children: lote.dataValidade ? (_jsx("span", { style: { fontWeight: 500 }, children: dataValidadeFmt })) : (_jsx("span", { style: { color: "var(--color-text-muted)" }, children: "N\u00E3o informada" })) }), _jsxs("td", { style: { padding: "8px 12px", textAlign: "right", fontVariantNumeric: "tabular-nums" }, children: [lote.quantidadeInicial.toLocaleString("pt-BR"), " ", p.unidadeMedida] }), _jsxs("td", { style: {
                                                                    padding: "8px 12px",
                                                                    textAlign: "right",
                                                                    fontWeight: 700,
                                                                    color: "#059669",
                                                                    fontVariantNumeric: "tabular-nums",
                                                                }, children: [lote.quantidadeAtual.toLocaleString("pt-BR"), " ", p.unidadeMedida] }), _jsx("td", { style: { padding: "8px 12px", textAlign: "right", fontVariantNumeric: "tabular-nums" }, children: lote.custoUnitario !== null && lote.custoUnitario !== undefined
                                                                    ? `R$ ${lote.custoUnitario.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                                                                    : "—" })] }, lote.id));
                                                }) })] }) })] })) }))] }, p.id));
        }) }));
}
function ModalEntradaEstoque({ form, produtos, erros, erroEnvio, salvando, onChange, onSubmit, onFechar, }) {
    useEffect(() => {
        const handler = (e) => {
            if (e.key === "Escape")
                onFechar();
        };
        document.addEventListener("keydown", handler);
        return () => document.removeEventListener("keydown", handler);
    }, [onFechar]);
    const produtoSelecionado = produtos.find((p) => p.id === form.produtoId);
    return (_jsxs("div", { role: "dialog", "aria-modal": "true", "aria-labelledby": "modal-entrada-titulo", style: {
            position: "fixed",
            inset: 0,
            zIndex: 1000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "16px",
        }, children: [_jsx("div", { onClick: onFechar, style: {
                    position: "absolute",
                    inset: 0,
                    background: "rgba(0,0,0,0.5)",
                    backdropFilter: "blur(2px)",
                }, "aria-hidden": "true" }), _jsxs("div", { style: {
                    position: "relative",
                    background: "var(--color-surface)",
                    borderRadius: "16px",
                    width: "100%",
                    maxWidth: "540px",
                    maxHeight: "90dvh",
                    overflowY: "auto",
                    boxShadow: "var(--shadow-lg)",
                }, children: [_jsxs("div", { style: {
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            padding: "20px 24px",
                            borderBottom: "1px solid var(--color-border)",
                            position: "sticky",
                            top: 0,
                            background: "var(--color-surface)",
                            zIndex: 1,
                        }, children: [_jsxs("div", { children: [_jsx("h2", { id: "modal-entrada-titulo", style: { margin: 0, fontSize: "18px", fontWeight: 700, color: "var(--color-text)" }, children: "Registrar Entrada de Mercadoria" }), _jsx("p", { style: { margin: "2px 0 0", fontSize: "13px", color: "var(--color-text-muted)" }, children: "Gera um novo lote e incrementa o saldo dispon\u00EDvel" })] }), _jsx("button", { id: "btn-fechar-modal-entrada", "aria-label": "Fechar formul\u00E1rio", onClick: onFechar, style: {
                                    background: "none",
                                    border: "none",
                                    fontSize: "20px",
                                    cursor: "pointer",
                                    color: "var(--color-text-muted)",
                                    padding: "4px",
                                    borderRadius: "4px",
                                    lineHeight: 1,
                                }, children: "\u2715" })] }), _jsxs("form", { id: "form-entrada-estoque", onSubmit: onSubmit, noValidate: true, style: { padding: "24px" }, children: [erroEnvio && (_jsxs("div", { role: "alert", style: {
                                    background: "#fef2f2",
                                    border: "1px solid #fca5a5",
                                    borderRadius: "8px",
                                    padding: "12px 16px",
                                    marginBottom: "20px",
                                    fontSize: "14px",
                                    color: "#991b1b",
                                    display: "flex",
                                    gap: "8px",
                                    alignItems: "flex-start",
                                }, children: [_jsx("span", { "aria-hidden": "true", children: "\u26A0\uFE0F" }), erroEnvio] })), _jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "18px" }, children: [_jsx(Campo, { id: "campo-entrada-produto", label: "Produto", obrigatorio: true, erro: erros.produtoId, children: _jsxs("select", { id: "campo-entrada-produto", name: "produtoId", value: form.produtoId, onChange: onChange, style: estiloInput, "aria-required": "true", children: [_jsx("option", { value: "", children: "Selecione o produto..." }), produtos.map((p) => (_jsxs("option", { value: p.id, children: [p.nome, " (", p.unidadeMedida, ") \u2014 Atual: ", p.saldoDisponivel, " ", p.unidadeMedida] }, p.id)))] }) }), _jsx(Campo, { id: "campo-entrada-quantidade", label: `Quantidade recebida${produtoSelecionado ? ` (${produtoSelecionado.unidadeMedida})` : ""}`, obrigatorio: true, erro: erros.quantidade, dica: "Deve ser maior que zero", children: _jsx("input", { id: "campo-entrada-quantidade", name: "quantidade", type: "number", min: "0.001", step: "0.001", value: form.quantidade, onChange: onChange, placeholder: "Ex: 10.5", style: estiloInput, "aria-required": "true" }) }), _jsx(Campo, { id: "campo-entrada-data", label: "Data de entrada", obrigatorio: true, erro: erros.dataEntrada, children: _jsx("input", { id: "campo-entrada-data", name: "dataEntrada", type: "date", value: form.dataEntrada, onChange: onChange, style: estiloInput, "aria-required": "true" }) }), _jsx(Campo, { id: "campo-entrada-validade", label: "Data de validade", erro: erros.dataValidade, dica: "Opcional \u2014 essencial para controle de perec\u00EDveis e FIFO", children: _jsx("input", { id: "campo-entrada-validade", name: "dataValidade", type: "date", value: form.dataValidade, onChange: onChange, style: estiloInput }) }), _jsx(Campo, { id: "campo-entrada-custo", label: "Custo unit\u00E1rio (R$)", erro: erros.custoUnitario, dica: "Opcional \u2014 valor pago por unidade desta mercadoria", children: _jsx("input", { id: "campo-entrada-custo", name: "custoUnitario", type: "number", min: "0", step: "0.01", value: form.custoUnitario, onChange: onChange, placeholder: "Ex: 8.90", style: estiloInput }) })] }), _jsxs("div", { style: {
                                    display: "flex",
                                    gap: "12px",
                                    justifyContent: "flex-end",
                                    marginTop: "28px",
                                    paddingTop: "20px",
                                    borderTop: "1px solid var(--color-border)",
                                }, children: [_jsx("button", { id: "btn-cancelar-entrada", type: "button", onClick: onFechar, disabled: salvando, style: {
                                            background: "none",
                                            border: "1.5px solid var(--color-border)",
                                            borderRadius: "8px",
                                            padding: "10px 20px",
                                            fontSize: "14px",
                                            fontWeight: 500,
                                            cursor: salvando ? "not-allowed" : "pointer",
                                            color: "var(--color-text-muted)",
                                        }, children: "Cancelar" }), _jsx("button", { id: "btn-confirmar-entrada", type: "submit", disabled: salvando, style: {
                                            background: salvando ? "#86efac" : "var(--color-primary)",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "8px",
                                            padding: "10px 24px",
                                            fontSize: "14px",
                                            fontWeight: 600,
                                            cursor: salvando ? "not-allowed" : "pointer",
                                            display: "flex",
                                            alignItems: "center",
                                            gap: "8px",
                                            minWidth: "150px",
                                            justifyContent: "center",
                                            transition: "background var(--transition)",
                                        }, children: salvando ? "Salvando lote..." : "Confirmar entrada" })] })] })] })] }));
}
// ---------------------------------------------------------------
// Catálogo de Produtos (Preservado da Etapa 2)
// ---------------------------------------------------------------
function TabelaCatalogoProdutos({ produtos }) {
    const COLUNAS_TABELA = [
        { label: "Produto", align: "left" },
        { label: "Categoria", align: "left", width: "160px" },
        { label: "Unidade", align: "center", width: "90px" },
        { label: "Estoque mínimo", align: "right", width: "150px" },
        { label: "Estoque ideal", align: "right", width: "150px" },
        { label: "Custo ref.", align: "right", width: "130px" },
    ];
    return (_jsxs("div", { style: {
            background: "var(--color-surface)",
            border: "1.5px solid var(--color-border)",
            borderRadius: "12px",
            overflow: "hidden",
            boxShadow: "var(--shadow-sm)",
        }, children: [_jsx("div", { className: "tabela-desktop", style: { overflowX: "auto" }, children: _jsxs("table", { style: { width: "100%", borderCollapse: "collapse", textAlign: "left" }, "aria-label": "Lista de produtos cadastrados", children: [_jsx("thead", { children: _jsx("tr", { style: { background: "var(--color-surface-2)", borderBottom: "1.5px solid var(--color-border)" }, children: COLUNAS_TABELA.map((col) => (_jsx("th", { scope: "col", style: {
                                        padding: "14px 18px",
                                        textAlign: col.align,
                                        fontSize: "12px",
                                        fontWeight: 700,
                                        color: "var(--color-text-muted)",
                                        textTransform: "uppercase",
                                        letterSpacing: "0.06em",
                                        whiteSpace: "nowrap",
                                        width: col.width,
                                    }, children: col.label }, col.label))) }) }), _jsx("tbody", { children: produtos.map((p, i) => (_jsxs("tr", { style: {
                                    borderBottom: i < produtos.length - 1 ? "1px solid var(--color-border)" : "none",
                                    transition: "background var(--transition)",
                                }, children: [_jsx("td", { style: { padding: "14px 18px", fontWeight: 600, color: "var(--color-text)", fontSize: "14px" }, children: p.nome }), _jsx("td", { style: { padding: "14px 18px", whiteSpace: "nowrap" }, children: _jsx("span", { style: {
                                                background: "#f0fdf4",
                                                color: "#166534",
                                                fontSize: "12px",
                                                padding: "4px 10px",
                                                borderRadius: "6px",
                                                fontWeight: 600,
                                                display: "inline-block",
                                            }, children: p.categoria }) }), _jsx("td", { style: { padding: "14px 18px", textAlign: "center", fontSize: "13px", color: "var(--color-text-muted)", fontWeight: 500, whiteSpace: "nowrap" }, children: _jsx("span", { style: { background: "var(--color-surface-2)", padding: "3px 8px", borderRadius: "4px" }, children: p.unidadeMedida }) }), _jsx("td", { style: { padding: "14px 18px", textAlign: "right", whiteSpace: "nowrap" }, children: _jsxs("span", { style: { fontSize: "14px", fontWeight: 600, color: "var(--color-text)", fontVariantNumeric: "tabular-nums" }, children: [p.estoqueMinimo.toLocaleString("pt-BR"), " ", p.unidadeMedida] }) }), _jsx("td", { style: { padding: "14px 18px", textAlign: "right", whiteSpace: "nowrap" }, children: _jsxs("span", { style: { fontSize: "14px", fontWeight: 600, color: "var(--color-text)", fontVariantNumeric: "tabular-nums" }, children: [p.estoqueIdeal.toLocaleString("pt-BR"), " ", p.unidadeMedida] }) }), _jsx("td", { style: { padding: "14px 18px", textAlign: "right", fontSize: "14px", color: "var(--color-text)", fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" }, children: p.custoReferencia !== null && p.custoReferencia !== undefined ? (_jsxs("span", { style: { fontWeight: 500 }, children: ["R$ ", p.custoReferencia.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })] })) : (_jsx("span", { style: { color: "var(--color-text-light)" }, children: "\u2014" })) })] }, p.id))) })] }) }), _jsx("div", { style: {
                    padding: "12px 18px",
                    background: "var(--color-surface-2)",
                    borderTop: "1px solid var(--color-border)",
                    fontSize: "12px",
                    fontWeight: 500,
                    color: "var(--color-text-muted)",
                }, children: _jsxs("span", { children: [produtos.length, " ", produtos.length === 1 ? "produto cadastrado" : "produtos cadastrados"] }) })] }));
}
// ---------------------------------------------------------------
// Estado vazio
// ---------------------------------------------------------------
function EstadoVazio({ busca, onCadastrar }) {
    if (busca) {
        return (_jsxs("div", { style: { textAlign: "center", padding: "48px 24px", color: "var(--color-text-muted)" }, children: [_jsx("span", { "aria-hidden": "true", style: { fontSize: "40px", display: "block", marginBottom: "12px" }, children: "\uD83D\uDD0D" }), _jsxs("p", { style: { margin: 0, fontSize: "15px" }, children: ["Nenhum produto encontrado para ", _jsxs("strong", { children: ["\u201C", busca, "\u201D"] }), "."] })] }));
    }
    return (_jsxs("div", { style: {
            background: "var(--color-surface)",
            border: "1.5px dashed var(--color-border)",
            borderRadius: "12px",
            textAlign: "center",
            padding: "60px 24px",
        }, children: [_jsx("span", { "aria-hidden": "true", style: { fontSize: "48px", display: "block", marginBottom: "16px" }, children: "\uD83D\uDCE6" }), _jsx("h2", { style: { margin: "0 0 8px", fontSize: "18px", fontWeight: 700, color: "var(--color-text)" }, children: "Nenhum produto cadastrado" }), _jsx("p", { style: { margin: "0 0 24px", fontSize: "14px", color: "var(--color-text-muted)" }, children: "Comece cadastrando os produtos do seu estabelecimento antes de dar entrada no estoque." }), _jsx("button", { id: "btn-cadastrar-primeiro-produto", onClick: onCadastrar, style: {
                    background: "var(--color-primary)",
                    color: "#fff",
                    border: "none",
                    borderRadius: "8px",
                    padding: "12px 24px",
                    fontSize: "14px",
                    fontWeight: 600,
                    cursor: "pointer",
                }, children: "Cadastrar primeiro produto" })] }));
}
function ModalCadastroProduto({ form, erros, erroEnvio, salvando, onChange, onSubmit, onFechar, }) {
    useEffect(() => {
        const handler = (e) => {
            if (e.key === "Escape")
                onFechar();
        };
        document.addEventListener("keydown", handler);
        return () => document.removeEventListener("keydown", handler);
    }, [onFechar]);
    return (_jsxs("div", { role: "dialog", "aria-modal": "true", "aria-labelledby": "modal-titulo", style: {
            position: "fixed",
            inset: 0,
            zIndex: 1000,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "16px",
        }, children: [_jsx("div", { onClick: onFechar, style: {
                    position: "absolute",
                    inset: 0,
                    background: "rgba(0,0,0,0.5)",
                    backdropFilter: "blur(2px)",
                }, "aria-hidden": "true" }), _jsxs("div", { style: {
                    position: "relative",
                    background: "var(--color-surface)",
                    borderRadius: "16px",
                    width: "100%",
                    maxWidth: "560px",
                    maxHeight: "90dvh",
                    overflowY: "auto",
                    boxShadow: "var(--shadow-lg)",
                }, children: [_jsxs("div", { style: {
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                            padding: "20px 24px",
                            borderBottom: "1px solid var(--color-border)",
                            position: "sticky",
                            top: 0,
                            background: "var(--color-surface)",
                            zIndex: 1,
                        }, children: [_jsx("h2", { id: "modal-titulo", style: { margin: 0, fontSize: "18px", fontWeight: 700, color: "var(--color-text)" }, children: "Cadastrar produto" }), _jsx("button", { id: "btn-fechar-modal", "aria-label": "Fechar formul\u00E1rio", onClick: onFechar, style: {
                                    background: "none",
                                    border: "none",
                                    fontSize: "20px",
                                    cursor: "pointer",
                                    color: "var(--color-text-muted)",
                                    padding: "4px",
                                    borderRadius: "4px",
                                    lineHeight: 1,
                                }, children: "\u2715" })] }), _jsxs("form", { id: "form-cadastro-produto", onSubmit: onSubmit, noValidate: true, style: { padding: "24px" }, children: [erroEnvio && (_jsxs("div", { role: "alert", style: {
                                    background: "#fef2f2",
                                    border: "1px solid #fca5a5",
                                    borderRadius: "8px",
                                    padding: "12px 16px",
                                    marginBottom: "20px",
                                    fontSize: "14px",
                                    color: "#991b1b",
                                    display: "flex",
                                    gap: "8px",
                                    alignItems: "flex-start",
                                }, children: [_jsx("span", { "aria-hidden": "true", children: "\u26A0\uFE0F" }), erroEnvio] })), _jsxs("div", { style: { display: "flex", flexDirection: "column", gap: "18px" }, children: [_jsx(Campo, { id: "campo-nome", label: "Nome do produto", obrigatorio: true, erro: erros.nome, children: _jsx("input", { id: "campo-nome", name: "nome", type: "text", value: form.nome, onChange: onChange, placeholder: "Ex: Tomate, Frango, Farinha de Trigo", maxLength: 200, style: estiloInput, autoFocus: true }) }), _jsx(Campo, { id: "campo-categoria", label: "Categoria", obrigatorio: true, erro: erros.categoria, children: _jsxs("select", { id: "campo-categoria", name: "categoria", value: form.categoria, onChange: onChange, style: estiloInput, children: [_jsx("option", { value: "", children: "Selecione uma categoria" }), CATEGORIAS_COMUNS.map((c) => (_jsx("option", { value: c, children: c }, c)))] }) }), _jsx(Campo, { id: "campo-unidade", label: "Unidade de medida", obrigatorio: true, erro: erros.unidadeMedida, children: _jsxs("select", { id: "campo-unidade", name: "unidadeMedida", value: form.unidadeMedida, onChange: onChange, style: estiloInput, children: [_jsx("option", { value: "", children: "Selecione a unidade" }), UNIDADES_COMUNS.map((u) => (_jsx("option", { value: u, children: u }, u)))] }) }), _jsxs("div", { style: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px" }, children: [_jsx(Campo, { id: "campo-estoque-minimo", label: "Estoque m\u00EDnimo", obrigatorio: true, erro: erros.estoqueMinimo, dica: "Disparo de alerta", children: _jsx("input", { id: "campo-estoque-minimo", name: "estoqueMinimo", type: "number", min: "0", step: "0.001", value: form.estoqueMinimo, onChange: onChange, placeholder: "0", style: estiloInput }) }), _jsx(Campo, { id: "campo-estoque-ideal", label: "Estoque ideal", obrigatorio: true, erro: erros.estoqueIdeal, dica: "Desejado em estoque", children: _jsx("input", { id: "campo-estoque-ideal", name: "estoqueIdeal", type: "number", min: "0", step: "0.001", value: form.estoqueIdeal, onChange: onChange, placeholder: "0", style: estiloInput }) })] }), _jsx(Campo, { id: "campo-custo", label: "Custo de refer\u00EAncia (R$)", erro: erros.custoReferencia, dica: "Opcional \u2014 usado para relat\u00F3rios", children: _jsx("input", { id: "campo-custo", name: "custoReferencia", type: "number", min: "0", step: "0.01", value: form.custoReferencia, onChange: onChange, placeholder: "Ex: 12.50", style: estiloInput }) })] }), _jsxs("div", { style: {
                                    display: "flex",
                                    gap: "12px",
                                    justifyContent: "flex-end",
                                    marginTop: "28px",
                                    paddingTop: "20px",
                                    borderTop: "1px solid var(--color-border)",
                                }, children: [_jsx("button", { id: "btn-cancelar-cadastro", type: "button", onClick: onFechar, disabled: salvando, style: {
                                            background: "none",
                                            border: "1.5px solid var(--color-border)",
                                            borderRadius: "8px",
                                            padding: "10px 20px",
                                            fontSize: "14px",
                                            fontWeight: 500,
                                            cursor: salvando ? "not-allowed" : "pointer",
                                            color: "var(--color-text-muted)",
                                        }, children: "Cancelar" }), _jsx("button", { id: "btn-salvar-produto", type: "submit", disabled: salvando, style: {
                                            background: salvando ? "#86efac" : "var(--color-primary)",
                                            color: "#fff",
                                            border: "none",
                                            borderRadius: "8px",
                                            padding: "10px 24px",
                                            fontSize: "14px",
                                            fontWeight: 600,
                                            cursor: salvando ? "not-allowed" : "pointer",
                                            display: "flex",
                                            alignItems: "center",
                                            gap: "8px",
                                            minWidth: "130px",
                                            justifyContent: "center",
                                            transition: "background var(--transition)",
                                        }, children: salvando ? "Salvando..." : "Salvar produto" })] })] })] })] }));
}
function Campo({ id, label, obrigatorio, erro, dica, children }) {
    return (_jsxs("div", { children: [_jsxs("label", { htmlFor: id, style: {
                    display: "block",
                    fontSize: "13px",
                    fontWeight: 600,
                    color: "var(--color-text)",
                    marginBottom: "6px",
                }, children: [label, obrigatorio && (_jsx("span", { "aria-hidden": "true", style: { color: "var(--color-danger)", marginLeft: "3px" }, children: "*" }))] }), dica && !erro && (_jsx("p", { style: { margin: "0 0 6px", fontSize: "12px", color: "var(--color-text-light)" }, children: dica })), children, erro && (_jsx("p", { id: `erro-${id}`, role: "alert", style: { margin: "5px 0 0", fontSize: "12px", color: "var(--color-danger)" }, children: erro }))] }));
}
// ---------------------------------------------------------------
// Estilos compartilhados
// ---------------------------------------------------------------
const estiloInput = {
    width: "100%",
    padding: "9px 12px",
    border: "1.5px solid var(--color-border)",
    borderRadius: "8px",
    fontSize: "14px",
    color: "var(--color-text)",
    background: "var(--color-surface)",
    outline: "none",
    transition: "border-color var(--transition)",
    boxSizing: "border-box",
    appearance: "auto",
};
