"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import { useEffect, useState } from "react";
const formatoData = (data) => {
    const [ano, mes, dia] = data.split("-");
    return `${dia}/${mes}/${ano}`;
};
function quantidade(valor, unidade) {
    return `${new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 3 }).format(valor)} ${unidade}`;
}
function CartaoResumo({ titulo, valor, cor }) {
    return (_jsxs("div", { style: { background: "var(--surface, #fff)", border: `1px solid ${cor}55`, borderLeft: `4px solid ${cor}`, borderRadius: 12, padding: "16px 18px", minWidth: 0 }, children: [_jsx("div", { style: { color: "var(--text-secondary, #64748b)", fontSize: 13 }, children: titulo }), _jsx("div", { style: { color: cor, fontSize: 28, fontWeight: 750, marginTop: 4 }, children: valor })] }));
}
function Secao({ titulo, descricao, itens, cor, vazio, render }) {
    return (_jsxs("section", { style: { background: "var(--surface, #fff)", border: "1px solid var(--border, #e2e8f0)", borderRadius: 14, overflow: "hidden", minWidth: 0 }, children: [_jsxs("div", { style: { padding: "16px 18px", borderBottom: "1px solid var(--border, #e2e8f0)", borderTop: `4px solid ${cor}` }, children: [_jsxs("h2", { style: { margin: 0, fontSize: 17 }, children: [titulo, " ", _jsxs("span", { style: { color: cor }, children: ["(", itens.length, ")"] })] }), _jsx("p", { style: { margin: "5px 0 0", color: "var(--text-secondary, #64748b)", fontSize: 13 }, children: descricao })] }), itens.length ? _jsx("ul", { style: { listStyle: "none", padding: 0, margin: 0 }, children: itens.map((item, index) => _jsx("li", { style: { padding: "14px 18px", borderBottom: index < itens.length - 1 ? "1px solid var(--border, #e2e8f0)" : undefined }, children: render(item) }, index)) }) : _jsx("p", { style: { margin: 0, padding: 18, color: "var(--text-secondary, #64748b)", fontSize: 14 }, children: vazio })] }));
}
function ItemBaixo({ item }) {
    return _jsxs("div", { style: { display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }, children: [_jsxs("div", { children: [_jsx("strong", { children: item.nome }), _jsx("div", { style: { color: "var(--text-secondary, #64748b)", fontSize: 12, marginTop: 3 }, children: item.categoria })] }), _jsxs("div", { style: { textAlign: "right", fontSize: 13 }, children: [_jsx("strong", { children: quantidade(item.saldoDisponivel, item.unidadeMedida) }), _jsxs("div", { style: { color: "var(--text-secondary, #64748b)", marginTop: 3 }, children: ["m\u00EDnimo ", quantidade(item.estoqueMinimo, item.unidadeMedida)] })] })] });
}
function ItemValidade({ item, vencido }) {
    const status = vencido ? `Vencido há ${Math.abs(item.dias)} ${Math.abs(item.dias) === 1 ? "dia" : "dias"}` : item.dias === 0 ? "Vence hoje" : item.dias === 1 ? "Vence amanhã" : `Vence em ${item.dias} dias`;
    return _jsxs("div", { style: { display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }, children: [_jsxs("div", { children: [_jsx("strong", { children: item.produtoNome }), _jsxs("div", { style: { color: "var(--text-secondary, #64748b)", fontSize: 12, marginTop: 3 }, children: ["Lote ", item.loteId.slice(0, 8), " \u00B7 ", item.categoria] })] }), _jsxs("div", { style: { textAlign: "right", fontSize: 13 }, children: [_jsx("strong", { children: status }), _jsxs("div", { style: { color: "var(--text-secondary, #64748b)", marginTop: 3 }, children: [formatoData(item.dataValidade), " \u00B7 ", quantidade(item.quantidadeAtual, item.unidadeMedida)] })] })] });
}
export default function AlertasClient() {
    const [alertas, setAlertas] = useState(null);
    const [carregando, setCarregando] = useState(true);
    const [erro, setErro] = useState("");
    async function carregar() {
        setCarregando(true);
        setErro("");
        try {
            const resposta = await fetch("/api/alertas", { cache: "no-store" });
            if (!resposta.ok)
                throw new Error("Falha ao carregar alertas.");
            setAlertas(await resposta.json());
        }
        catch {
            setErro("Não foi possível carregar os alertas. Tente novamente.");
        }
        finally {
            setCarregando(false);
        }
    }
    useEffect(() => {
        const timer = window.setTimeout(() => { void carregar(); }, 0);
        return () => window.clearTimeout(timer);
    }, []);
    return _jsxs("main", { style: { padding: "28px clamp(16px, 3vw, 32px)", maxWidth: 1240, margin: "0 auto", width: "100%", boxSizing: "border-box" }, children: [_jsxs("header", { style: { marginBottom: 22 }, children: [_jsx("h1", { style: { fontSize: 26, margin: 0 }, children: "Alertas de estoque" }), _jsxs("p", { style: { color: "var(--text-secondary, #64748b)", margin: "7px 0 0", fontSize: 14 }, children: ["Saldos calculados pelos lotes atuais. Validades consideradas at\u00E9 7 dias a partir de ", alertas ? formatoData(alertas.dataReferencia) : "hoje", " (", alertas?.fusoHorario ?? "America/Manaus", ")."] })] }), carregando && _jsx("p", { role: "status", children: "Carregando alertas\u2026" }), erro && _jsxs("div", { role: "alert", style: { padding: 16, borderRadius: 10, background: "#fef2f2", color: "#b91c1c", display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }, children: [erro, _jsx("button", { onClick: () => void carregar(), children: "Tentar novamente" })] }), alertas && !carregando && _jsxs(_Fragment, { children: [_jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 210px), 1fr))", gap: 12, marginBottom: 22 }, children: [_jsx(CartaoResumo, { titulo: "Estoque abaixo do m\u00EDnimo", valor: alertas.resumo.estoqueBaixo, cor: "#d97706" }), _jsx(CartaoResumo, { titulo: "Lotes vencidos", valor: alertas.resumo.vencidos, cor: "#dc2626" }), _jsx(CartaoResumo, { titulo: "Vencem em at\u00E9 7 dias", valor: alertas.resumo.vencemEm7Dias, cor: "#ca8a04" })] }), _jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 340px), 1fr))", gap: 16 }, children: [_jsx(Secao, { titulo: "Estoque baixo", descricao: "Produtos ativos com saldo total dos lotes abaixo do m\u00EDnimo.", itens: alertas.estoqueBaixo, cor: "#d97706", vazio: "Nenhum produto abaixo do estoque m\u00EDnimo.", render: (item) => _jsx(ItemBaixo, { item: item }) }), _jsx(Secao, { titulo: "Produtos vencidos", descricao: "Lotes com saldo positivo e validade anterior \u00E0 data de hoje.", itens: alertas.vencidos, cor: "#dc2626", vazio: "Nenhum lote vencido com saldo.", render: (item) => _jsx(ItemValidade, { item: item, vencido: true }) }), _jsx(Secao, { titulo: "Pr\u00F3ximos do vencimento", descricao: "Lotes com saldo positivo que vencem hoje ou nos pr\u00F3ximos 7 dias.", itens: alertas.proximosDoVencimento, cor: "#ca8a04", vazio: "Nenhum lote vence nos pr\u00F3ximos 7 dias.", render: (item) => _jsx(ItemValidade, { item: item, vencido: false }) })] })] })] });
}
