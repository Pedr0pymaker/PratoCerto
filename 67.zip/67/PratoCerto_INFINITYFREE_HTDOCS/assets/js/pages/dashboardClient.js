"use client";
import { jsx as _jsx, jsxs as _jsxs, Fragment as _Fragment } from "react/jsx-runtime";
import Link from "/assets/js/compat/link.js";
import { useEffect, useState } from "react";
const surface = "var(--color-surface, #fff)";
const border = "var(--color-border, #e2e8f0)";
const muted = "var(--color-text-muted, #64748b)";
const primary = "var(--color-primary, #4f46e5)";
function numero(valor, casas = 3) {
    return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: casas }).format(valor);
}
function dataLocal(iso) {
    return new Intl.DateTimeFormat("pt-BR", {
        dateStyle: "short",
        timeStyle: "short",
        timeZone: "America/Manaus",
    }).format(new Date(iso));
}
function dataCalendario(iso) {
    const [ano, mes, dia] = iso.slice(0, 10).split("-");
    return `${dia}/${mes}/${ano}`;
}
function Cartao({ icon, label, valor, descricao, href, cor }) {
    return _jsx(Link, { href: href, style: { color: "inherit", textDecoration: "none", minWidth: 0 }, children: _jsxs("article", { style: { height: "100%", boxSizing: "border-box", background: surface, border: `1px solid ${border}`, borderTop: `4px solid ${cor}`, borderRadius: 12, padding: 17, transition: "box-shadow 150ms" }, children: [_jsxs("div", { style: { display: "flex", alignItems: "center", gap: 9, color: muted, fontSize: 13 }, children: [_jsx("span", { "aria-hidden": "true", children: icon }), label] }), _jsx("div", { style: { fontSize: 27, fontWeight: 800, letterSpacing: "-0.7px", marginTop: 9 }, children: valor }), _jsxs("div", { style: { color: muted, fontSize: 12, marginTop: 5 }, children: [descricao, " ", _jsx("span", { "aria-hidden": "true", children: "\u2197" })] })] }) });
}
function ListaSecao({ titulo, itens, temItens, href, children, vazio }) {
    return _jsxs("section", { style: { background: surface, border: `1px solid ${border}`, borderRadius: 12, minWidth: 0, overflow: "hidden" }, children: [_jsxs("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, padding: "15px 18px", borderBottom: `1px solid ${border}` }, children: [_jsxs("h2", { style: { margin: 0, fontSize: 16 }, children: [titulo, " ", _jsxs("span", { style: { color: muted, fontSize: 13 }, children: ["(", itens, ")"] })] }), _jsx(Link, { href: href, style: { color: primary, fontSize: 13, fontWeight: 600, whiteSpace: "nowrap" }, children: "Ver todos \u2192" })] }), !temItens ? _jsx("p", { style: { padding: "12px 18px", color: muted, fontSize: 13 }, children: vazio }) : _jsx("div", { children: children })] });
}
export default function DashboardClient() {
    const [dados, setDados] = useState(null);
    const [carregando, setCarregando] = useState(true);
    const [erro, setErro] = useState("");
    async function carregar() {
        setCarregando(true);
        setErro("");
        try {
            const resposta = await fetch("/api/dashboard", { cache: "no-store" });
            if (!resposta.ok)
                throw new Error("Falha ao carregar dashboard");
            setDados(await resposta.json());
        }
        catch {
            setErro("Não foi possível carregar os indicadores. Tente novamente.");
        }
        finally {
            setCarregando(false);
        }
    }
    useEffect(() => {
        const timer = window.setTimeout(() => { void carregar(); }, 0);
        return () => window.clearTimeout(timer);
    }, []);
    return _jsxs("main", { style: { padding: "26px clamp(16px, 3vw, 32px)", maxWidth: 1400, margin: "0 auto", width: "100%", boxSizing: "border-box" }, children: [_jsxs("header", { style: { marginBottom: 22 }, children: [_jsx("h1", { style: { margin: 0, fontSize: 25, fontWeight: 750 }, children: "Dashboard" }), _jsx("p", { style: { margin: "6px 0 0", color: muted, fontSize: 14 }, children: "Vis\u00E3o geral do estoque e das movimenta\u00E7\u00F5es do estabelecimento." })] }), carregando && _jsx("p", { role: "status", style: { color: muted }, children: "Carregando dados do Dashboard\u2026" }), erro && _jsxs("div", { role: "alert", style: { background: "#fef2f2", color: "#b91c1c", padding: 15, borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12 }, children: [erro, _jsx("button", { onClick: () => void carregar(), children: "Tentar novamente" })] }), dados && !carregando && _jsxs(_Fragment, { children: [_jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 195px), 1fr))", gap: 12, marginBottom: 22 }, children: [_jsx(Cartao, { icon: "\uD83D\uDCE6", label: "Produtos ativos", valor: numero(dados.resumo.produtosAtivos, 0), descricao: "No cat\u00E1logo", href: "/estoque", cor: primary }), _jsx(Cartao, { icon: "\u26A0\uFE0F", label: "Abaixo do m\u00EDnimo", valor: numero(dados.resumo.estoqueBaixo, 0), descricao: "Produtos para repor", href: "/alertas", cor: "#d97706" }), _jsx(Cartao, { icon: "\u26D4", label: "Lotes vencidos", valor: numero(dados.resumo.lotesVencidos, 0), descricao: "Com saldo dispon\u00EDvel", href: "/alertas", cor: "#dc2626" }), _jsx(Cartao, { icon: "\uD83D\uDDD3\uFE0F", label: "Vencem em 7 dias", valor: numero(dados.resumo.lotesVencemEm7Dias, 0), descricao: "Inclui os que vencem hoje", href: "/alertas", cor: "#ca8a04" }), _jsx(Cartao, { icon: "\uD83D\uDCC9", label: "Registros de perdas", valor: numero(dados.resumo.totalPerdas, 0), descricao: `${new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(dados.resumo.custoEstimadoPerdas)} de custo estimado`, href: "/perdas", cor: "#be123c" })] }), _jsxs("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(min(100%, 360px), 1fr))", gap: 16, marginBottom: 20 }, children: [_jsx(ListaSecao, { titulo: "Produtos abaixo do m\u00EDnimo", itens: dados.resumo.estoqueBaixo, temItens: dados.alertas.estoqueBaixo.length > 0, href: "/alertas", vazio: "Nenhum produto est\u00E1 abaixo do estoque m\u00EDnimo.", children: dados.alertas.estoqueBaixo.map((item) => _jsxs(Link, { href: "/alertas", style: { display: "flex", justifyContent: "space-between", gap: 12, padding: "12px 18px", borderBottom: `1px solid ${border}`, textDecoration: "none", color: "inherit", fontSize: 13 }, children: [_jsx("strong", { children: item.nome }), _jsxs("span", { style: { textAlign: "right", color: muted }, children: [numero(item.saldoDisponivel), " / ", numero(item.estoqueMinimo), " ", item.unidadeMedida] })] }, item.produtoId)) }), _jsx(ListaSecao, { titulo: "Lotes vencidos", itens: dados.resumo.lotesVencidos, temItens: dados.alertas.vencidos.length > 0, href: "/alertas", vazio: "Nenhum lote vencido com saldo positivo.", children: dados.alertas.vencidos.map((item) => _jsxs(Link, { href: "/alertas", style: { display: "flex", justifyContent: "space-between", gap: 12, padding: "12px 18px", borderBottom: `1px solid ${border}`, textDecoration: "none", color: "inherit", fontSize: 13 }, children: [_jsx("strong", { children: item.produtoNome }), _jsxs("span", { style: { textAlign: "right", color: "#b91c1c" }, children: [dataCalendario(item.dataValidade), " \u00B7 ", numero(item.quantidadeAtual), " ", item.unidadeMedida] })] }, item.loteId)) }), _jsx(ListaSecao, { titulo: "Pr\u00F3ximos do vencimento", itens: dados.resumo.lotesVencemEm7Dias, temItens: dados.alertas.proximosDoVencimento.length > 0, href: "/alertas", vazio: "Nenhum lote vence nos pr\u00F3ximos 7 dias.", children: dados.alertas.proximosDoVencimento.map((item) => _jsxs(Link, { href: "/alertas", style: { display: "flex", justifyContent: "space-between", gap: 12, padding: "12px 18px", borderBottom: `1px solid ${border}`, textDecoration: "none", color: "inherit", fontSize: 13 }, children: [_jsx("strong", { children: item.produtoNome }), _jsxs("span", { style: { textAlign: "right", color: "#a16207" }, children: [dataCalendario(item.dataValidade), " \u00B7 ", numero(item.quantidadeAtual), " ", item.unidadeMedida] })] }, item.loteId)) })] }), _jsx(ListaSecao, { titulo: "Movimenta\u00E7\u00F5es recentes", itens: dados.movimentacoes.length, temItens: dados.movimentacoes.length > 0, href: "/estoque", vazio: "Ainda n\u00E3o h\u00E1 entradas nem registros de perdas.", children: dados.movimentacoes.map((item) => _jsxs(Link, { href: item.href, style: { display: "grid", gridTemplateColumns: "minmax(0, 1fr) auto", gap: "4px 14px", padding: "12px 18px", borderBottom: `1px solid ${border}`, textDecoration: "none", color: "inherit" }, children: [_jsxs("strong", { style: { fontSize: 13 }, children: [item.tipo === "ENTRADA" ? "📥" : "📉", " ", item.produtoNome] }), _jsx("span", { style: { fontSize: 12, color: muted, textAlign: "right" }, children: dataLocal(item.dataHora) }), _jsx("span", { style: { fontSize: 12, color: muted }, children: item.descricao }), _jsxs("span", { style: { fontSize: 12, textAlign: "right" }, children: [item.tipo === "ENTRADA" ? "+" : "−", numero(item.quantidade), " ", item.unidadeMedida] })] }, item.id)) })] }), !carregando && !erro && dados && dados.resumo.produtosAtivos === 0 && dados.resumo.totalPerdas === 0 && dados.movimentacoes.length === 0 && _jsx("p", { style: { marginTop: 18, color: muted, fontSize: 13 }, children: "Cadastre produtos e registre entradas para come\u00E7ar a acompanhar os indicadores." })] });
}
