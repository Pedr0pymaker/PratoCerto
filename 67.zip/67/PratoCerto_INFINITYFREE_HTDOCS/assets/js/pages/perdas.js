import { jsx as _jsx } from "react/jsx-runtime";
import PerdasClient from "/assets/js/pages/perdasClient.js";
export const metadata = {
    title: "Perdas — PratoCerto",
    description: "Registro e acompanhamento de perdas e desperdícios.",
};
export default function PerdasPage() {
    return _jsx(PerdasClient, {});
}
