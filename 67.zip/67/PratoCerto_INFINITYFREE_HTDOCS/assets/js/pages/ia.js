import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import ComingSoon from "/assets/js/components/ComingSoon.js";
export const metadata = {
    title: "PratoCerto IA — PratoCerto",
    description: "Assistente inteligente para análise dos seus dados.",
};
export default function IAPage() {
    return (_jsxs("div", { children: [_jsxs("div", { style: { marginBottom: "28px" }, children: [_jsx("h1", { style: { margin: "0 0 6px", fontSize: "24px", fontWeight: 700, color: "var(--color-text)" }, children: "PratoCerto IA" }), _jsx("p", { style: { margin: 0, fontSize: "14px", color: "var(--color-text-muted)" }, children: "Assistente inteligente baseado nos seus dados reais" })] }), _jsx(ComingSoon, { title: "Assistente PratoCerto IA", description: "O assistente de IA analisar\u00E1 os dados reais do seu estabelecimento e responder\u00E1 perguntas em linguagem natural. Ele sempre informar\u00E1 quando os dados forem insuficientes e n\u00E3o inventar\u00E1 informa\u00E7\u00F5es.", icon: "\uD83E\uDD16", plannedFeatures: [
                    "Respostas baseadas apenas em dados reais do sistema",
                    "Perguntas em linguagem natural sobre estoque, perdas e compras",
                    "Indicação clara quando não há dados suficientes",
                    "Recomendações de apoio à decisão (sem ações automáticas críticas)",
                    "Sugestões de aproveitamento responsável de alimentos",
                    "Respeito às permissões de cada perfil de usuário",
                ] })] }));
}
