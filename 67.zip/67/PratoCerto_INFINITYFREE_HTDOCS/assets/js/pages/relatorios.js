import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import ComingSoon from "/assets/js/components/ComingSoon.js";
export const metadata = {
    title: "Relatórios — PratoCerto",
    description: "Análises de estoque, perdas e consumo por período.",
};
export default function RelatoriosPage() {
    return (_jsxs("div", { children: [_jsxs("div", { style: { marginBottom: "28px" }, children: [_jsx("h1", { style: { margin: "0 0 6px", fontSize: "24px", fontWeight: 700, color: "var(--color-text)" }, children: "Relat\u00F3rios" }), _jsx("p", { style: { margin: 0, fontSize: "14px", color: "var(--color-text-muted)" }, children: "An\u00E1lises e exporta\u00E7\u00F5es por per\u00EDodo" })] }), _jsx(ComingSoon, { title: "M\u00F3dulo de Relat\u00F3rios", description: "Aqui voc\u00EA poder\u00E1 gerar relat\u00F3rios detalhados sobre estoque, perdas, consumo e compras, filtrando por per\u00EDodo, produto ou categoria.", icon: "\uD83D\uDCC8", plannedFeatures: [
                    "Relatório de desperdício por período, produto, categoria e motivo",
                    "Cálculo do valor financeiro estimado das perdas",
                    "Comparativo entre períodos",
                    "Relatório de movimentações de estoque",
                    "Relatório de compras e gastos por fornecedor",
                    "Exportação de dados (etapa futura)",
                ] })] }));
}
