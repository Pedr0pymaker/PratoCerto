import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import ComingSoon from "/assets/js/components/ComingSoon.js";
export const metadata = {
    title: "Configurações — PratoCerto",
    description: "Preferências e configurações do estabelecimento.",
};
export default function ConfiguracoesPage() {
    return (_jsxs("div", { children: [_jsxs("div", { style: { marginBottom: "28px" }, children: [_jsx("h1", { style: { margin: "0 0 6px", fontSize: "24px", fontWeight: 700, color: "var(--color-text)" }, children: "Configura\u00E7\u00F5es" }), _jsx("p", { style: { margin: 0, fontSize: "14px", color: "var(--color-text-muted)" }, children: "Prefer\u00EAncias do estabelecimento e do sistema" })] }), _jsx(ComingSoon, { title: "M\u00F3dulo de Configura\u00E7\u00F5es", description: "Aqui voc\u00EA poder\u00E1 configurar as prefer\u00EAncias do seu estabelecimento, definir alertas, personalizar categorias de produtos e ajustar o comportamento do sistema.", icon: "\u2699\uFE0F", plannedFeatures: [
                    "Dados do estabelecimento (nome, tipo, informações gerais)",
                    "Preferências de alertas (dias para vencer, abaixo do mínimo)",
                    "Habilitação/desabilitação de baixa automática por receita",
                    "Categorias personalizadas de produtos",
                    "Unidades de medida utilizadas no estabelecimento",
                    "Preferências de acessibilidade",
                ] })] }));
}
