import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import ComingSoon from "/assets/js/components/ComingSoon.js";
export const metadata = {
    title: "Receitas — PratoCerto",
    description: "Fichas técnicas e controle de ingredientes por receita.",
};
export default function ReceitasPage() {
    return (_jsxs("div", { children: [_jsxs("div", { style: { marginBottom: "28px" }, children: [_jsx("h1", { style: { margin: "0 0 6px", fontSize: "24px", fontWeight: 700, color: "var(--color-text)" }, children: "Receitas" }), _jsx("p", { style: { margin: 0, fontSize: "14px", color: "var(--color-text-muted)" }, children: "Fichas t\u00E9cnicas e baixa autom\u00E1tica de ingredientes" })] }), _jsx(ComingSoon, { title: "M\u00F3dulo de Receitas", description: "Aqui voc\u00EA poder\u00E1 cadastrar fichas t\u00E9cnicas dos pratos do seu card\u00E1pio, associando ingredientes e quantidades para que o sistema calcule automaticamente o consumo de estoque.", icon: "\uD83C\uDF7D\uFE0F", plannedFeatures: [
                    "Cadastro de receitas com nome do prato e ingredientes",
                    "Definição de quantidade por ingrediente por porção",
                    "Baixa automática de ingredientes ao registrar consumo (quando habilitado)",
                    "Visualização do custo estimado por prato",
                    "Ativação e desativação de receitas",
                ] })] }));
}
