import { jsx as _jsx } from "react/jsx-runtime";
import DashboardClient from "/assets/js/pages/dashboardClient.js";
export const metadata = {
    title: "Dashboard — PratoCerto",
    description: "Visão geral do estoque, alertas e indicadores do seu estabelecimento.",
};
export default function DashboardPage() {
    return _jsx(DashboardClient, {});
}
