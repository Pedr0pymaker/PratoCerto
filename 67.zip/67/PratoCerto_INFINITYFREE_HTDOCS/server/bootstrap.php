<?php
declare(strict_types=1);
// PratoCerto InfinityFree - PHP 8.1+ e MySQL, sem Node ou Prisma no servidor.
date_default_timezone_set('America/Manaus');
function cfg(string $key, string $fallback = ''): string {
    static $data = null;
    if ($data === null) {
        $data = [];
        $path = dirname(__DIR__) . '/.env';
        if (is_file($path) && is_readable($path)) {
            foreach (file($path, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
                $line = trim(preg_replace('/^\xEF\xBB\xBF/', '', $line));
                if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
                [$k, $v] = explode('=', $line, 2);
                $k = trim($k); $v = trim($v);
                if (strlen($v) > 1 && ($v[0] === '"' || $v[0] === "'") && substr($v, -1) === $v[0]) $v = substr($v, 1, -1);
                $data[$k] = $v;
            }
        }
    }
    $env = getenv($key);
    return $env !== false ? (string)$env : ($data[$key] ?? $fallback);
}
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
$secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
if (session_status() !== PHP_SESSION_ACTIVE) {
    ini_set('session.use_strict_mode','1');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$secure,'httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
function db(): PDO {
    static $pdo;
    if (isset($pdo)) return $pdo;
    $host = cfg('DB_HOST'); $name = cfg('DB_NAME'); $user = cfg('DB_USER');
    if (!$host || !$name || !$user || !cfg('DB_PASS')) throw new RuntimeException('Banco não configurado. Veja INSTALAR_INFINITYFREE.md.');
    $pdo = new PDO(
        'mysql:host=' . $host . ';port=' . cfg('DB_PORT', '3306') . ';dbname=' . $name . ';charset=utf8mb4',
        $user, cfg('DB_PASS'),
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES=>false]
    );
    try { $pdo->exec("SET time_zone = '+00:00'"); } catch (PDOException $ignored) {}
    return $pdo;
}
function rows(string $query, array $params=[]): array { $s=db()->prepare($query); $s->execute($params); return $s->fetchAll(); }
function one(string $query, array $params=[]): ?array { $s=db()->prepare($query);$s->execute($params);$r=$s->fetch();return $r?:null; }
function execute(string $query,array $params=[]): int { $s=db()->prepare($query); $s->execute($params);return $s->rowCount(); }
function charLen(string $text):int {return function_exists("mb_strlen") ? mb_strlen($text, "UTF-8") : strlen($text);}
function uid():string {return bin2hex(random_bytes(13));}
function iso(?string $s):?string { return $s === null ? null : str_replace(' ','T',substr($s,0,19)).'Z'; }
function out(array $data,int $status=200):never { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE|JSON_THROW_ON_ERROR);exit; }
function err(string $message,int $status=422):never {out(['erro'=>$message],$status);}
function validation(array $errors):never {out(['erros'=>$errors],422);}
function check(bool $cond, string $message, string $field='geral'):void {if(!$cond) validation([['campo'=>$field,'mensagem'=>$message]]);}
function body():array {
    if (!str_starts_with(strtolower($_SERVER['CONTENT_TYPE']??''),'application/json')) err('Envie JSON com Content-Type application/json.',415);
    $raw=file_get_contents('php://input');
    if (strlen($raw)>524288)err('Requisição muito grande.',413);
    $data=json_decode($raw,true);if (!is_array($data)||array_is_list($data))err('JSON inválido.',400);
    return $data;
}
function num($v,int $scale=3):?int {
    if (!is_string($v) && !is_int($v) && !is_float($v)) return null;
    $str=(string)$v;
    if (!preg_match('/^\d+(?:\.\d{1,'.$scale.'})?$/D',$str))return null;
    [$a,$b]=array_pad(explode('.',$str,2),2,'');
    if(strlen($a)>10)return null;
    return ((int)$a*10**$scale)+((int)str_pad($b,$scale,'0'));
}
function fqty($v):float {return round((float)$v,3);}
function money($v):float {return round((float)$v,2);}
function dec(int $scaled,int $scale):string {return sprintf('%d.%0'.$scale.'d',intdiv($scaled,10**$scale),$scaled%(10**$scale));}
function dateOnly($v):?string {
    if (!is_string($v) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D',$v,$m) || !checkdate((int)$m[2],(int)$m[3],(int)$m[1]))return null;
    return $v;
}
function datetime($v):?string {return ($d=dateOnly(is_string($v)?substr($v,0,10):'') )? $d.' 00:00:00':null;}
function user():?array {
    if (empty($_SESSION['user_id']))return null;
    $u=one('SELECT id,nome,email,perfil,ativo FROM usuarios WHERE id=?',[$_SESSION['user_id']]);
    if(!$u||!(int)$u['ativo']){unset($_SESSION['user_id']);return null;}
    return ['id'=>$u['id'],'nome'=>$u['nome'],'email'=>$u['email'],'perfil'=>$u['perfil']];
}
function loginRequired():array { $u=user();if(!$u)err('Não autenticado.',401);return $u; }
function managerRequired():array { $u=loginRequired();if($u['perfil']!=='GERENTE')err('Acesso negado. Apenas GERENTE.',403);return $u; }
function sameOrigin():void {
    $origin=$_SERVER['HTTP_ORIGIN']??'';
    if($origin){$h=parse_url($origin,PHP_URL_HOST); if(!is_string($h)||strcasecmp($h, explode(':', $_SERVER['HTTP_HOST'] ?? '')[0])!==0)err('Origem não autorizada.',403);}
    $site=$_SERVER['HTTP_SEC_FETCH_SITE']??'';
    if($site==='cross-site')err('Requisição não autorizada.',403);
}
function safeError(Throwable $e):never {error_log('[PratoCerto] '.$e->getMessage());err('Não foi possível concluir a operação. Verifique a conexão e a configuração do banco.',500);}
