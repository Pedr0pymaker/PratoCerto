<?php
declare(strict_types=1);
require_once __DIR__.'/bootstrap.php';
function products():array {
    $all=rows('SELECT id,nome,categoria,unidadeMedida,estoqueMinimo,estoqueIdeal,custoReferencia FROM produtos WHERE ativo=1 ORDER BY nome');
    foreach($all as &$p){$p['estoqueMinimo']=fqty($p['estoqueMinimo']);$p['estoqueIdeal']=fqty($p['estoqueIdeal']);$p['custoReferencia']=$p['custoReferencia']===null?null:money($p['custoReferencia']);}unset($p);
    return $all;
}
function lotsByProducts(array $products):array {
    $map=[];foreach($products as $p)$map[$p['id']]=[];
    $all=rows('SELECT id,produtoId,quantidadeInicial,quantidadeAtual,dataEntrada,dataValidade,custoUnitario,criadoEm FROM lotes_estoque ORDER BY dataValidade IS NULL, dataValidade, dataEntrada');
    foreach($all as $l){if(!isset($map[$l['produtoId']]))continue;
        $l['quantidadeInicial']=fqty($l['quantidadeInicial']);$l['quantidadeAtual']=fqty($l['quantidadeAtual']);
        $l['custoUnitario']=$l['custoUnitario']===null?null:money($l['custoUnitario']);
        foreach(['dataEntrada','dataValidade','criadoEm'] as $key)$l[$key]=iso($l[$key]);
        $map[$l['produtoId']][]=$l;
    }
    return $map;
}
function inventory():array {
    $ps=products();$map=lotsByProducts($ps);
    foreach($ps as &$p){$p['lotes']=$map[$p['id']]??[];
        $milli=array_reduce($p['lotes'],fn($sum,$l)=>$sum+(int)round($l['quantidadeAtual']*1000),0);
        $p['saldoDisponivel']=$milli/1000;
        $p['situacao']=$milli<(int)round($p['estoqueMinimo']*1000)?'ABAIXO_MINIMO':'NORMAL';
    }unset($p);return $ps;
}
function alerts(array $ps):array {
    $today=(new DateTimeImmutable('now',new DateTimeZone('America/Manaus')))->format('Y-m-d');
    $low=[];$expired=[];$soon=[];
    foreach($ps as $p){if($p['saldoDisponivel']<$p['estoqueMinimo'])$low[]=['produtoId'=>$p['id'],'nome'=>$p['nome'],'categoria'=>$p['categoria'],'unidadeMedida'=>$p['unidadeMedida'],'saldoDisponivel'=>$p['saldoDisponivel'],'estoqueMinimo'=>$p['estoqueMinimo']];
        foreach($p['lotes'] as $l){if($l['quantidadeAtual']<=0||!$l['dataValidade'])continue;
            $date=substr($l['dataValidade'],0,10);$days=(int)((strtotime($date.' 12:00:00')-strtotime($today.' 12:00:00'))/86400);
            $entry=['loteId'=>$l['id'],'produtoId'=>$p['id'],'produtoNome'=>$p['nome'],'categoria'=>$p['categoria'],'unidadeMedida'=>$p['unidadeMedida'],'quantidadeAtual'=>$l['quantidadeAtual'],'dataValidade'=>$date,'dias'=>$days];
            if($days<0)$expired[]=$entry;elseif($days<=7)$soon[]=$entry;
        }
    }
    $sort=fn($a,$b)=>strcmp($a['dataValidade'],$b['dataValidade'])?:strcmp($a['produtoNome'],$b['produtoNome']);
    usort($expired,$sort);usort($soon,$sort);
    return ['dataReferencia'=>$today,'fusoHorario'=>'America/Manaus','diasAntecedencia'=>7,
        'resumo'=>['estoqueBaixo'=>count($low),'vencidos'=>count($expired),'vencemEm7Dias'=>count($soon),'total'=>count($low)+count($expired)+count($soon)],
        'estoqueBaixo'=>$low,'vencidos'=>$expired,'proximosDoVencimento'=>$soon];
}
function serializedOrder(array $p):array {
    $it=rows('SELECT i.id,i.produtoId,p.nome produtoNome,p.unidadeMedida,i.quantidade,i.custoUnitario,i.total,i.dataValidade FROM itens_pedido_compra i JOIN produtos p ON p.id=i.produtoId WHERE i.pedidoId=? ORDER BY i.id',[$p['id']]);
    foreach($it as &$i){$i['quantidade']=number_format((float)$i['quantidade'],3,'.','');$i['custoUnitario']=number_format((float)$i['custoUnitario'],2,'.','');$i['total']=number_format((float)$i['total'],2,'.','');$i['dataValidade']=$i['dataValidade']?substr($i['dataValidade'],0,10):null;}unset($i);
    return ['id'=>$p['id'],'fornecedor'=>$p['fornecedor'],'dataPedido'=>substr($p['dataPedido'],0,10),'observacoes'=>$p['observacoes'],'status'=>$p['status'],
        'total'=>number_format((float)$p['total'],2,'.',''),'dataRecebimento'=>iso($p['dataRecebimento']),'dataCancelamento'=>iso($p['dataCancelamento']),'criadoEm'=>iso($p['criadoEm']),'itens'=>$it];
}
