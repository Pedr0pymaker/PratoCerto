<?php
declare(strict_types=1);
require_once dirname(__DIR__).'/server/data.php';
header('Cache-Control: no-store');
$route=trim((string)($_GET['route']??''),'/');
$method=$_SERVER['REQUEST_METHOD']??'GET';
if(!in_array($method,['GET','POST'],true)){header('Allow: GET, POST');err('Método não permitido.',405);}
if($method==='POST')sameOrigin();
try{
// Autenticação
if($route==='auth/login'&&$method==='POST'){
    $b=body();$email=strtolower(trim((string)($b['email']??'')));$pass=$b['senha']??'';
    check(filter_var($email,FILTER_VALIDATE_EMAIL)!==false,'Informe um email válido.','email');
    check(is_string($pass)&&$pass!=='','Informe a senha.','senha');
    $u=one('SELECT id,nome,email,perfil,senhaHash,ativo FROM usuarios WHERE email=?',[$email]);
    if(!$u||!(int)$u['ativo']||!password_verify($pass,$u['senhaHash']))err('Email ou senha incorretos.',401);
    session_regenerate_id(true);$_SESSION['user_id']=$u['id'];
    out(['mensagem'=>'Login realizado com sucesso.','usuario'=>['id'=>$u['id'],'nome'=>$u['nome'],'email'=>$u['email'],'perfil'=>$u['perfil']]]);
}
if($route==='auth/logout'&&$method==='POST'){
    $_SESSION=[];session_regenerate_id(true);out(['mensagem'=>'Logout realizado com sucesso.']);
}
if($route==='auth/me'&&$method==='GET'){
    $u=user();if(!$u)out(['autenticado'=>false,'usuario'=>null],401);
    out(['autenticado'=>true,'usuario'=>$u]);
}
$actor=loginRequired();
// Produtos
if($route==='produtos'&&$method==='GET')out(['produtos'=>products()]);
if($route==='produtos'&&$method==='POST'){
    $b=body();$name=trim((string)($b['nome']??''));$cat=trim((string)($b['categoria']??''));$unit=trim((string)($b['unidadeMedida']??''));
    check(charLen($name)>=2&&charLen($name)<=200,'Nome precisa ter entre 2 e 200 caracteres.','nome');
    check($cat!==''&&charLen($cat)<=100,'Informe categoria válida.','categoria');
    check($unit!==''&&charLen($unit)<=50,'Informe unidade válida.','unidadeMedida');
    $min=num($b['estoqueMinimo']??null);$ideal=num($b['estoqueIdeal']??null);
    check($min!==null,'Estoque mínimo inválido.','estoqueMinimo');check($ideal!==null,'Estoque ideal inválido.','estoqueIdeal');
    $cost=($b['custoReferencia']??'')===''?null:num($b['custoReferencia'],2);
    check($cost!==null||($b['custoReferencia']??'')==='','Custo de referência inválido.','custoReferencia');
    $id=uid();execute('INSERT INTO produtos (id,nome,categoria,unidadeMedida,estoqueMinimo,estoqueIdeal,custoReferencia,ativo,atualizadoEm) VALUES (?,?,?,?,?,?,?,1,NOW(3))',[$id,$name,$cat,$unit,dec($min,3),dec($ideal,3),$cost===null?null:dec($cost,2)]);
    out(['mensagem'=>'Produto cadastrado com sucesso.','produto'=>['id'=>$id,'nome'=>$name,'categoria'=>$cat,'unidadeMedida'=>$unit,'estoqueMinimo'=>$min/1000,'estoqueIdeal'=>$ideal/1000,'custoReferencia'=>$cost===null?null:$cost/100]],201);
}
// Estoque
if($route==='estoque'&&$method==='GET')out(['produtos'=>inventory()]);
if($route==='estoque'&&$method==='POST'){
    $b=body();$id=(string)($b['produtoId']??'');$qty=num($b['quantidade']??null);$entry=datetime($b['dataEntrada']??null);
    $valid=empty($b['dataValidade'])?null:datetime($b['dataValidade']);
    $cost=($b['custoUnitario']??'')===''?null:num($b['custoUnitario'],2);
    check($id!=='','Selecione um produto.','produtoId');check($qty!==null&&$qty>0,'Quantidade inválida.','quantidade');
    check($entry!==null,'Data de entrada inválida.','dataEntrada');check(empty($b['dataValidade'])||$valid!==null,'Validade inválida.','dataValidade');
    check($cost!==null||($b['custoUnitario']??'')==='','Custo inválido.','custoUnitario');
    $p=one('SELECT id FROM produtos WHERE id=? AND ativo=1',[$id]);if(!$p)err('Produto não encontrado ou inativo.',404);
    $lot=uid();execute('INSERT INTO lotes_estoque (id,produtoId,quantidadeInicial,quantidadeAtual,dataEntrada,dataValidade,custoUnitario) VALUES (?,?,?,?,?,?,?)',[$lot,$id,dec($qty,3),dec($qty,3),$entry,$valid,$cost===null?null:dec($cost,2)]);
    $saldo=one('SELECT COALESCE(SUM(quantidadeAtual),0) saldo FROM lotes_estoque WHERE produtoId=?',[$id]);
    out(['mensagem'=>'Entrada de estoque registrada com sucesso.','lote'=>['id'=>$lot,'produtoId'=>$id,'quantidadeInicial'=>$qty/1000,'quantidadeAtual'=>$qty/1000,'dataEntrada'=>iso($entry),'dataValidade'=>iso($valid),'custoUnitario'=>$cost===null?null:$cost/100,'criadoEm'=>gmdate('Y-m-d\TH:i:s\Z')],'saldoDisponivel'=>fqty($saldo['saldo'])],201);
}
// Perdas
if($route==='perdas'&&$method==='GET'){
    $where=' WHERE 1=1';$p=[];
    if(in_array($_GET['motivo']??'', ['VENCIMENTO','DETERIORACAO','SOBRA','PREPARO_ACIDENTE','OUTRO'],true)){$where.=' AND a.motivo=?';$p[]=$_GET['motivo'];}
    if(!empty($_GET['dataInicio'])&&dateOnly($_GET['dataInicio'])){$where.=' AND a.dataHora >= ?';$p[]=datetime($_GET['dataInicio']);}
    if(!empty($_GET['dataFim'])&&dateOnly($_GET['dataFim'])){$where.=' AND a.dataHora < DATE_ADD(?,INTERVAL 1 DAY)';$p[]=datetime($_GET['dataFim']);}
    $result=rows('SELECT a.*,p.nome produtoNome,p.categoria produtoCategoria,p.unidadeMedida produtoUnidade,u.nome usuarioNome FROM perdas a JOIN produtos p ON p.id=a.produtoId JOIN usuarios u ON u.id=a.usuarioId '.$where.' ORDER BY a.dataHora DESC LIMIT 500',$p);
    foreach($result as &$r){$r['quantidade']=fqty($r['quantidade']);$r['custoEstimado']=money($r['custoEstimado']);$r['dataHora']=iso($r['dataHora']);}unset($r);
    out(['perdas'=>$result]);
}
if($route==='perdas'&&$method==='POST'){
    $b=body();$pid=(string)($b['produtoId']??'');$qty=num($b['quantidade']??null);$reason=(string)($b['motivo']??'');$note=trim((string)($b['observacao']??''));
    check($qty!==null&&$qty>0,'Quantidade inválida.','quantidade');
    check(in_array($reason,['VENCIMENTO','DETERIORACAO','SOBRA','PREPARO_ACIDENTE','OUTRO'],true),'Motivo inválido.','motivo');
    check(charLen($note)<=500,'Observação muito longa.','observacao');
    $pdo=db();$pdo->beginTransaction();
    try{
        $p=one('SELECT * FROM produtos WHERE id=? AND ativo=1',[$pid]);if(!$p){$pdo->rollBack();err('Produto não encontrado.',404);}
        $lots=rows('SELECT id,quantidadeAtual,custoUnitario FROM lotes_estoque WHERE produtoId=? AND quantidadeAtual>0 ORDER BY dataEntrada,id FOR UPDATE',[$pid]);
        $available=array_sum(array_map(fn($l)=>(int)round((float)$l['quantidadeAtual']*1000),$lots));
        if($available<$qty){$pdo->rollBack();err('Estoque insuficiente. Saldo disponível: '.($available/1000).' '.$p['unidadeMedida'].'.',422);}
        $remain=$qty;$costThousandCents=0;
        foreach($lots as $l){if(!$remain)break;
            $lotqty=(int)round((float)$l['quantidadeAtual']*1000);$take=min($lotqty,$remain);
            $price=(int)round((float)($l['custoUnitario']??0)*100);$costThousandCents+=$take*$price;
            execute('UPDATE lotes_estoque SET quantidadeAtual=? WHERE id=?',[dec($lotqty-$take,3),$l['id']]);$remain-=$take;
        }
        $cents=intdiv($costThousandCents+500,1000);$id=uid();
        execute('INSERT INTO perdas (id,produtoId,usuarioId,quantidade,motivo,custoEstimado,observacao) VALUES (?,?,?,?,?,?,?)',[$id,$pid,$actor['id'],dec($qty,3),$reason,dec($cents,2),$note===''?null:$note]);
        $pdo->commit();out(['mensagem'=>'Perda registrada com sucesso.','perda'=>['id'=>$id,'produtoId'=>$pid,'produtoNome'=>$p['nome'],'usuarioNome'=>$actor['nome'],'quantidade'=>$qty/1000,'motivo'=>$reason,'custoEstimado'=>$cents/100,'observacao'=>$note?:null,'dataHora'=>gmdate('Y-m-d\TH:i:s\Z')],'saldoDisponivel'=>($available-$qty)/1000],201);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
// Alertas e dashboard
if($route==='alertas'&&$method==='GET')out(alerts(inventory()));
if($route==='dashboard'&&$method==='GET'){
    $ps=inventory();$a=alerts($ps);
    $sum=one('SELECT COUNT(*) qtd, COALESCE(SUM(custoEstimado),0) custo FROM perdas');
    $recentE=rows('SELECT l.id,l.produtoId,l.quantidadeInicial quantidade,l.dataEntrada dataHora,p.nome produtoNome,p.unidadeMedida FROM lotes_estoque l JOIN produtos p ON p.id=l.produtoId ORDER BY l.dataEntrada DESC LIMIT 8');
    $recentP=rows('SELECT a.id,a.produtoId,a.quantidade,a.motivo,a.dataHora,p.nome produtoNome,p.unidadeMedida FROM perdas a JOIN produtos p ON p.id=a.produtoId ORDER BY a.dataHora DESC LIMIT 8');
    $mov=[];foreach($recentE as $r)$mov[]=['id'=>'entrada-'.$r['id'],'tipo'=>'ENTRADA','produtoId'=>$r['produtoId'],'produtoNome'=>$r['produtoNome'],'unidadeMedida'=>$r['unidadeMedida'],'quantidade'=>fqty($r['quantidade']),'dataHora'=>iso($r['dataHora']),'descricao'=>'Entrada de estoque','href'=>'/estoque'];
    foreach($recentP as $r)$mov[]=['id'=>'perda-'.$r['id'],'tipo'=>'PERDA','produtoId'=>$r['produtoId'],'produtoNome'=>$r['produtoNome'],'unidadeMedida'=>$r['unidadeMedida'],'quantidade'=>fqty($r['quantidade']),'dataHora'=>iso($r['dataHora']),'descricao'=>'Perda · '.$r['motivo'],'href'=>'/perdas'];
    usort($mov,fn($x,$y)=>strcmp($y['dataHora'],$x['dataHora']));
    out(['resumo'=>['produtosAtivos'=>count($ps),'estoqueBaixo'=>$a['resumo']['estoqueBaixo'],'lotesVencidos'=>$a['resumo']['vencidos'],'lotesVencemEm7Dias'=>$a['resumo']['vencemEm7Dias'],'totalPerdas'=>(int)$sum['qtd'],'custoEstimadoPerdas'=>money($sum['custo'])],
       'alertas'=>['estoqueBaixo'=>array_slice($a['estoqueBaixo'],0,5),'vencidos'=>array_slice($a['vencidos'],0,5),'proximosDoVencimento'=>array_slice($a['proximosDoVencimento'],0,5)],'movimentacoes'=>array_slice($mov,0,8)]);
}
// Usuários
if($route==='usuarios'&&$method==='GET'){
    managerRequired();$us=rows('SELECT id,nome,email,perfil,ativo,criadoEm FROM usuarios ORDER BY criadoEm DESC');
    foreach($us as &$u){$u['ativo']=(bool)$u['ativo'];$u['criadoEm']=iso($u['criadoEm']);}unset($u);out(['usuarios'=>$us]);
}
if($route==='usuarios'&&$method==='POST'){
    managerRequired();$b=body();$name=trim((string)($b['nome']??''));$email=strtolower(trim((string)($b['email']??'')));$pass=$b['senha']??'';$profile=(string)($b['perfil']??'');
    check(charLen($name)>=3&&charLen($name)<=150,'Nome inválido.','nome');check(filter_var($email,FILTER_VALIDATE_EMAIL)!==false&&strlen($email)<=150,'Email inválido.','email');
    check(is_string($pass)&&strlen($pass)>=8,'Senha deve ter no mínimo 8 caracteres.','senha');check(in_array($profile,['GERENTE','FUNCIONARIO'],true),'Perfil inválido.','perfil');
    if(one('SELECT id FROM usuarios WHERE email=?',[$email]))validation([['campo'=>'email','mensagem'=>'Já existe um usuário cadastrado com este email.']]);
    $id=uid();execute('INSERT INTO usuarios (id,nome,email,senhaHash,perfil,ativo,atualizadoEm) VALUES (?,?,?,?,?,1,NOW(3))',[$id,$name,$email,password_hash($pass,PASSWORD_BCRYPT),$profile]);
    out(['mensagem'=>'Usuário cadastrado com sucesso.','usuario'=>['id'=>$id,'nome'=>$name,'email'=>$email,'perfil'=>$profile,'ativo'=>true,'criadoEm'=>gmdate('Y-m-d\TH:i:s\Z')]],201);
}
// Compras
if($route==='compras'&&$method==='GET'){
    $ps=rows('SELECT * FROM pedidos_compra ORDER BY dataPedido DESC,criadoEm DESC LIMIT 200');
    out(['pedidos'=>array_map('serializedOrder',$ps)]);
}
if($route==='compras'&&$method==='POST'){
    $b=body();$when=datetime($b['dataPedido']??null);$supplier=trim((string)($b['fornecedor']??''));$note=trim((string)($b['observacoes']??''));$items=$b['itens']??null;
    check($when!==null,'Data do pedido inválida.','dataPedido');check(charLen($supplier)<=200,'Fornecedor muito longo.','fornecedor');check(charLen($note)<=500,'Observação muito longa.','observacoes');
    check(is_array($items)&&count($items)>=1&&count($items)<=100,'Inclua de 1 a 100 itens.','itens');
    $clean=[];$total=0;
    foreach($items as $idx=>$i){check(is_array($i),'Item inválido.','itens.'.$idx);
        $pid=(string)($i['produtoId']??'');$q=num($i['quantidade']??null);$cost=num($i['custoUnitario']??null,2);
        check($pid!==''&&$q!==null&&$q>0&&$cost!==null,'Produto, quantidade ou custo inválido.','itens.'.$idx);
        $cents=intdiv($q*$cost+500,1000);$total+=$cents;
        check($total<=999999999999,'Total ultrapassou o limite.','itens');
        $clean[]=['id'=>uid(),'pid'=>$pid,'qty'=>$q,'cost'=>$cost,'cents'=>$cents];
    }
    $pdo=db();$pdo->beginTransaction();
    try{
        foreach(array_unique(array_column($clean,'pid')) as $pid){if(!one('SELECT id FROM produtos WHERE id=? AND ativo=1',[$pid])){$pdo->rollBack();err('Um ou mais produtos não existem ou estão inativos.',422);}}
        $id=uid();execute('INSERT INTO pedidos_compra (id,fornecedor,dataPedido,observacoes,total,atualizadoEm) VALUES (?,?,?,?,?,NOW(3))',[$id,$supplier?:null,$when,$note?:null,dec($total,2)]);
        foreach($clean as $i)execute('INSERT INTO itens_pedido_compra (id,pedidoId,produtoId,quantidade,custoUnitario,total) VALUES (?,?,?,?,?,?)',[$i['id'],$id,$i['pid'],dec($i['qty'],3),dec($i['cost'],2),dec($i['cents'],2)]);
        $pdo->commit();$p=one('SELECT * FROM pedidos_compra WHERE id=?',[$id]);out(['pedido'=>serializedOrder($p)],201);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
if(preg_match('#^compras/([a-zA-Z0-9_-]+)/(?:(receber)|(cancelar))$#D',$route,$m)&&$method==='POST'){
    $id=$m[1];$action=$m[2]??'';$pdo=db();$payload=$action==='receber'?body():[];
    $pdo->beginTransaction();
    try{
        $p=one('SELECT * FROM pedidos_compra WHERE id=? FOR UPDATE',[$id]);
        if(!$p){$pdo->rollBack();err('Pedido não encontrado.',404);}
        if($p['status']!=='PENDENTE'){$pdo->rollBack();err('Somente pedidos pendentes podem ser recebidos ou cancelados.',409);}
        if($action==='cancelar'){
            execute('UPDATE pedidos_compra SET status="CANCELADO",dataCancelamento=NOW(3),atualizadoEm=NOW(3) WHERE id=?',[$id]);$pdo->commit();out(['mensagem'=>'Pedido cancelado.']);
        }
        $when=datetime($payload['dataEntrada']??null);check($when!==null,'Data de recebimento inválida.','dataEntrada');
        $items=rows('SELECT * FROM itens_pedido_compra WHERE pedidoId=?',[$id]);
        $receipts=$payload['itens']??null;check(is_array($receipts)&&count($receipts)===count($items),'Informe todos os itens.','itens');
        $receiptMap=[];foreach($receipts as $r){check(is_array($r)&&isset($r['itemId']),'Item inválido.','itens');$rid=(string)$r['itemId'];check(!isset($receiptMap[$rid]),'Item duplicado.','itens');$v=empty($r['dataValidade'])?null:datetime($r['dataValidade']);check(empty($r['dataValidade'])||$v!==null,'Validade inválida.','itens');$receiptMap[$rid]=$v;}
        foreach($items as $it){check(array_key_exists($it['id'],$receiptMap),'Os itens não correspondem ao pedido.','itens');if(!one('SELECT id FROM produtos WHERE id=? AND ativo=1',[$it['produtoId']])){$pdo->rollBack();err('Produto não encontrado ou inativo.',422);}}
        execute('UPDATE pedidos_compra SET status="RECEBIDO",dataRecebimento=?,atualizadoEm=NOW(3) WHERE id=?',[$when,$id]);
        foreach($items as $it){$v=$receiptMap[$it['id']];execute('INSERT INTO lotes_estoque (id,produtoId,quantidadeInicial,quantidadeAtual,dataEntrada,dataValidade,custoUnitario) VALUES (?,?,?,?,?,?,?)',[uid(),$it['produtoId'],$it['quantidade'],$it['quantidade'],$when,$v,$it['custoUnitario']]);execute('UPDATE itens_pedido_compra SET dataValidade=? WHERE id=?',[$v,$it['id']]);}
        $pdo->commit();out(['mensagem'=>'Pedido recebido e lotes registrados.','pedidoId'=>$id,'lotesCriados'=>count($items)]);
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();throw $e;}
}
err('Rota não encontrada.',404);
}catch(Throwable $e){safeError($e);}
