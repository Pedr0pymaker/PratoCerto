-- PratoCerto - instalação NOVA em banco VAZIO no InfinityFree.
-- Crie e SELECIONE o banco no phpMyAdmin; NAO use CREATE DATABASE nem USE.
-- Preserva nomes e estruturas do Prisma original; nao cria usuarios predefinidos.


-- 20261006183049_init_mysql

-- CreateTable
CREATE TABLE `produtos` (
    `id` VARCHAR(191) NOT NULL,
    `nome` VARCHAR(200) NOT NULL,
    `categoria` VARCHAR(100) NOT NULL,
    `unidadeMedida` VARCHAR(50) NOT NULL,
    `estoqueMinimo` DECIMAL(10, 3) NOT NULL,
    `estoqueIdeal` DECIMAL(10, 3) NOT NULL,
    `custoReferencia` DECIMAL(10, 2) NULL,
    `ativo` BOOLEAN NOT NULL DEFAULT true,
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `atualizadoEm` DATETIME(3) NOT NULL,

    INDEX `produtos_ativo_idx`(`ativo`),
    INDEX `produtos_categoria_idx`(`categoria`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `usuarios` (
    `id` VARCHAR(191) NOT NULL,
    `nome` VARCHAR(150) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    `senhaHash` VARCHAR(255) NOT NULL,
    `perfil` VARCHAR(20) NOT NULL DEFAULT 'FUNCIONARIO',
    `ativo` BOOLEAN NOT NULL DEFAULT true,
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `atualizadoEm` DATETIME(3) NOT NULL,

    UNIQUE INDEX `usuarios_email_key`(`email`),
    INDEX `usuarios_email_idx`(`email`),
    INDEX `usuarios_perfil_idx`(`perfil`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;


-- 20261013184515_add_lote_estoque

-- CreateTable
CREATE TABLE `lotes_estoque` (
    `id` VARCHAR(191) NOT NULL,
    `produtoId` VARCHAR(191) NOT NULL,
    `quantidadeInicial` DECIMAL(10, 3) NOT NULL,
    `quantidadeAtual` DECIMAL(10, 3) NOT NULL,
    `dataEntrada` DATETIME(3) NOT NULL,
    `dataValidade` DATETIME(3) NULL,
    `custoUnitario` DECIMAL(10, 2) NULL,
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `lotes_estoque_produtoId_idx`(`produtoId`),
    INDEX `lotes_estoque_dataValidade_idx`(`dataValidade`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `lotes_estoque` ADD CONSTRAINT `lotes_estoque_produtoId_fkey` FOREIGN KEY (`produtoId`) REFERENCES `produtos`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;


-- 20261020181712_add_perda

-- CreateTable
CREATE TABLE `perdas` (
    `id` VARCHAR(191) NOT NULL,
    `produtoId` VARCHAR(191) NOT NULL,
    `usuarioId` VARCHAR(191) NOT NULL,
    `quantidade` DECIMAL(10, 3) NOT NULL,
    `motivo` VARCHAR(30) NOT NULL,
    `custoEstimado` DECIMAL(10, 2) NOT NULL,
    `observacao` VARCHAR(500) NULL,
    `dataHora` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

    INDEX `perdas_produtoId_idx`(`produtoId`),
    INDEX `perdas_usuarioId_idx`(`usuarioId`),
    INDEX `perdas_motivo_idx`(`motivo`),
    INDEX `perdas_dataHora_idx`(`dataHora`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `perdas` ADD CONSTRAINT `perdas_produtoId_fkey` FOREIGN KEY (`produtoId`) REFERENCES `produtos`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `perdas` ADD CONSTRAINT `perdas_usuarioId_fkey` FOREIGN KEY (`usuarioId`) REFERENCES `usuarios`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;


-- 20261020190000_add_compras

CREATE TABLE `pedidos_compra` (
    `id` VARCHAR(191) NOT NULL,
    `fornecedor` VARCHAR(200) NULL,
    `dataPedido` DATETIME(3) NOT NULL,
    `observacoes` VARCHAR(500) NULL,
    `status` ENUM('PENDENTE', 'RECEBIDO', 'CANCELADO') NOT NULL DEFAULT 'PENDENTE',
    `total` DECIMAL(12, 2) NOT NULL,
    `dataRecebimento` DATETIME(3) NULL,
    `dataCancelamento` DATETIME(3) NULL,
    `criadoEm` DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
    `atualizadoEm` DATETIME(3) NOT NULL,

    INDEX `pedidos_compra_status_dataPedido_idx`(`status`, `dataPedido`),
    INDEX `pedidos_compra_dataPedido_idx`(`dataPedido`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `itens_pedido_compra` (
    `id` VARCHAR(191) NOT NULL,
    `pedidoId` VARCHAR(191) NOT NULL,
    `produtoId` VARCHAR(191) NOT NULL,
    `quantidade` DECIMAL(10, 3) NOT NULL,
    `custoUnitario` DECIMAL(10, 2) NOT NULL,
    `total` DECIMAL(12, 2) NOT NULL,
    `dataValidade` DATETIME(3) NULL,

    INDEX `itens_pedido_compra_pedidoId_idx`(`pedidoId`),
    INDEX `itens_pedido_compra_produtoId_idx`(`produtoId`),
    PRIMARY KEY (`id`)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

ALTER TABLE `itens_pedido_compra` ADD CONSTRAINT `itens_pedido_compra_pedidoId_fkey`
    FOREIGN KEY (`pedidoId`) REFERENCES `pedidos_compra`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `itens_pedido_compra` ADD CONSTRAINT `itens_pedido_compra_produtoId_fkey`
    FOREIGN KEY (`produtoId`) REFERENCES `produtos`(`id`) ON DELETE RESTRICT ON UPDATE CASCADE;
