# PratoCerto — Instalação no InfinityFree

**Este é um PORT para PHP/MySQL do projeto original Next.js + React + Prisma.** O servidor não precisa de Node.js, npm, Prisma, Vercel ou terminal. As telas originais foram mantidas como módulos React e o banco preserva o modelo original de 6 tabelas. A API HTTP foi reimplementada em PHP.

## Passo 1 — Criar MySQL

No InfinityFree, entre em **MySQL Databases** e crie um banco. Anote **MySQL Hostname**, **Database Name** e **MySQL Username**. A senha é a do MySQL da hospedagem. Não use `localhost` nem invente nomes; use exatamente os dados do painel.

Abra o **phpMyAdmin** desse banco, selecione o banco recém-criado (vazio), escolha **Importar** e envie `database/INSTALACAO_INFINITYFREE.sql`.

**IMPORTANTE:** esse arquivo serve para banco **novo/vazio**. Não execute em banco que já contém dados, sem fazer um backup e avaliar conflitos. Não crie bancos pelo SQL no InfinityFree; a criação é feita no painel.

## Passo 2 — Enviar site

Entre em **File Manager → htdocs**. Exclua a página inicial padrão do provedor, se houver, e envie **o conteúdo do ZIP `PratoCerto_INFINITYFREE_HTDOCS.zip`** para dentro do `htdocs`, diretamente (sem pasta `PratoCerto-master`, `app` ou `PratoCerto_INFINITYFREE_HTDOCS` entre eles).

Depois confira que existem:

- `htdocs/index.php`
- `htdocs/setup.php`
- `htdocs/.htaccess`
- `htdocs/api/index.php`
- `htdocs/server/bootstrap.php`
- `htdocs/assets/js/pages/login.js`

## Passo 3 — Configurar banco e instalação

No `htdocs`, copie `.env.example` para `.env` e edite os valores:

```ini
DB_HOST=sqlXXX.infinityfree.com
DB_PORT=3306
DB_NAME=if0_XXXXXXXX_pratocerto
DB_USER=if0_XXXXXXXX
DB_PASS=SUA_SENHA_REAL_MYSQL
SETUP_TOKEN=UM_TOKEN_ALEATORIO_DE_64_CARACTERES_HEXADECIMAIS
APP_ENV=production
```

**Não é a senha da conta do site ou do Gmail!** `DB_PASS` é a senha de banco de dados configurada na hospedagem. Não publique `.env` no GitHub nem compartilhe capturas contendo esses campos.

Para criar o `SETUP_TOKEN`, extraia o arquivo `docs/gerar_token_offline.html` no seu computador e abra no navegador. Clique em **Gerar SETUP_TOKEN**, copie os 64 caracteres hexadecimais gerados e coloque em `.env` na linha `SETUP_TOKEN=`. O exemplo não funciona como token, de propósito.

**Antes de inserir credenciais reais**, acesse `https://SEU-DOMINIO/.env`: tem que responder **403 ou 404**, sem exibir o conteúdo. Se aparecer o texto, corrija `.htaccess` antes de prosseguir.

## Passo 4 — Criar gerente

Com o banco importado e `.env` pronto, visite:

`https://SEU-DOMINIO/setup.php`

Preencha nome, email e uma senha pessoal com pelo menos 10 caracteres, além do mesmo `SETUP_TOKEN` salvo no `.env`. A primeira conta será **GERENTE**. Não há senha de administrador pública nem login padrão. Quando a primeira conta é criada, o instalador bloqueia novas contas por essa via.

Depois entre em `https://SEU-DOMINIO/login` e acesse o dashboard. No painel **Usuários**, um GERENTE pode criar contas `GERENTE` e `FUNCIONARIO`.

## Passo 5 — Testar módulos

1. **Dashboard:** carrega, inicialmente zerado.
2. **Estoque:** cadastrar produto, registrar entrada e confirmar que saldo e lotes aparecem.
3. **Alertas:** ajustar estoque mínimo / validade nas entradas e conferir avisos.
4. **Perdas:** registrar perda, verificar baixa FIFO e atualização do saldo.
5. **Compras:** criar pedido, receber itens para gerar lotes, ou cancelar pendente.
6. **Usuários:** GERENTE gerencia perfis; FUNCIONARIO não tem acesso ao endpoint `/api/usuarios`.
7. **Receitas, Relatórios, IA e Configurações:** no projeto **original essas telas eram informativas / “Em breve”**, e continuam assim; não foram apresentadas como funções completas.
8. **Segurança:** `/.env`, `/server/bootstrap.php`, `/database/INSTALACAO_INFINITYFREE.sql` e `/docs/gerar_token_offline.html` devem retornar **403/404** externamente.

## Tecnologias e limitações

- **Servidor:** PHP 8.1+ e PDO MySQL. O servidor Next.js 16, Prisma e scripts Node foram substituídos por PHP.
- **Interface:** as páginas originais React/TSX foram transpiladas previamente para JavaScript e permanecem com React 19. O navegador carrega React 19 de `esm.sh` por HTTPS. Portanto a interface **precisa de acesso à internet e ao CDN**; se o CDN estiver bloqueado, a página não carregará os componentes. Isso não exige Node no InfinityFree.
- A autenticação original JWT foi adaptada para **sessões PHP com cookie HttpOnly**. Senhas antigas gravadas com hash bcrypt do Next.js continuam verificáveis pelo PHP.
- As operações monetárias principais foram escritas com valores escalados em centavos e quantidades em milésimos. Perdas usam baixa FIFO em transação, e receber pedido gera lotes atomicamente.
- Só foram verificados sintaxe PHP/JS, caminhos e respostas HTTP sem banco; **o login, as operações MySQL e os fluxos integrados ainda devem ser testados na hospedagem real**.
- Um banco já existente exige análise antes de importar; a estrutura SQL base foi preservada.

## Se algo falhar

- **404 em `/estoque` ou `/api/estoque`:** verifique se `.htaccess` e `index.php` estão na raiz do `htdocs` e se o host habilita rewrite.
- **500/conexão:** revise dados MySQL no `.env` e tabelas importadas.
- **Tela presa em Carregando:** teste acesso ao CDN `https://esm.sh/` no navegador; abra F12 → Console e Network.
- **Login inválido após migração de banco:** confira que o hash da senha no MySQL é bcrypt e a conta está ativa; não copie senhas simples na coluna `senhaHash`.
- **SQL já executado:** não importe novamente em um banco com dados sem backup.

## Privacidade

O sistema contém informação sobre compras, funcionários e perdas. Defina senhas únicas, divulgue a URL apenas a pessoas autorizadas e use sempre HTTPS. Teste autenticação e permissões antes de usar dados reais.
